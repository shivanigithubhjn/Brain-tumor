"""Quantitative Grad-CAM evaluation against the expert tumour masks of the Figshare dataset.

For every test fold (seed 0 checkpoints) Grad-CAM maps are computed for the predicted class and
compared with the tumour mask:
  * IoU      : CAM thresholded at 0.5 (after per-image min-max scaling) vs. mask
  * PG       : pointing game - the CAM maximum falls inside the (8-px dilated) mask
  * EPG      : energy-based pointing game - fraction of CAM energy inside the mask
Usage: python xai.py --runs runs --data_dir ./figshare --out results
"""
import argparse
import gc as _gc
import json
import os

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from data import CLASS_NAMES, FigshareDataset, load_cache, load_folds, split_indices
from model import build_model

MODELS = {"MATRANSNET": ("matransnet", "matransnet_full_dwfl_c0.5"),
          "RESNET50": ("resnet50", "resnet50_full_ce_c0"),
          "CONVNEXT": ("convnext_tiny", "convnext_tiny_full_ce_c0"),
          "SWINT": ("swin_tiny", "swin_tiny_full_ce_c0")}


def target_layer(name, m):
    if name == "matransnet":
        return m.cam_layer(), False
    if name == "resnet50":
        return m.layer4, False
    if name == "convnext_tiny":
        return m.stages[-1], False
    if name == "swin_tiny":
        return m.layers[-1], True      # NHWC output
    raise ValueError(name)


class GradCAM:
    def __init__(self, model, layer, nhwc=False):
        self.m, self.nhwc, self.a, self.g = model, nhwc, None, None
        layer.register_forward_hook(lambda mod, i, o: setattr(self, "a", o))
        layer.register_full_backward_hook(lambda mod, gi, go: setattr(self, "g", go[0]))

    def __call__(self, x):
        self.m.zero_grad()
        logits = self.m(x)
        cls = logits.argmax(1)
        logits.gather(1, cls[:, None]).sum().backward()
        a, g = self.a, self.g
        if self.nhwc:
            a, g = a.permute(0, 3, 1, 2), g.permute(0, 3, 1, 2)
        cam = F.relu((g.mean((2, 3), keepdim=True) * a).sum(1, keepdim=True)).detach()
        self.a = self.g = None                               # release the autograd graph
        cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)[:, 0]
        mn = cam.flatten(1).min(1)[0][:, None, None]; mx = cam.flatten(1).max(1)[0][:, None, None]
        return ((cam - mn) / (mx - mn + 1e-8)).detach().cpu().numpy(), cls.cpu().numpy()


def scores(cam, mask):
    m = mask > 0.5
    b = cam >= 0.5
    iou = (b & m).sum() / max((b | m).sum(), 1)
    md = cv2.dilate(m.astype(np.uint8), np.ones((17, 17), np.uint8)) > 0
    pg = float(md.flat[cam.argmax()])
    epg = cam[m].sum() / max(cam.sum(), 1e-8)
    return iou, pg, epg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs"); ap.add_argument("--data_dir", required=True)
    ap.add_argument("--out", default="results"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max_batches", type=int, default=0)
    a = ap.parse_args()
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data = load_cache(a.data_dir)
    folds = load_folds(a.data_dir, data["labels"], data["pids"], data["idx"])
    R, examples = {}, {}
    for key, (name, group) in MODELS.items():
        S = []
        for k in range(5):
            run = os.path.join(a.runs, f"{group}_f{k}_s{a.seed}")
            if not os.path.exists(os.path.join(run, "best.pt")):
                continue
            cfg = json.load(open(os.path.join(run, "config.json")))
            _, _, te = split_indices(folds, k)
            m = build_model(name, pretrained=False, variant=cfg.get("variant", "full")).to(dev).eval()
            m.load_state_dict(torch.load(os.path.join(run, "best.pt"), map_location=dev))
            layer, nhwc = target_layer(name, m)
            gc = GradCAM(m, layer, nhwc)
            dl = DataLoader(FigshareDataset(data, te, 224, False, cfg["norm_mean"], cfg["norm_std"]), 16)
            for b, (x, y, mask, idx) in enumerate(dl):
                if a.max_batches and b >= a.max_batches:
                    break
                cams, pred = gc(x.to(dev).requires_grad_(True))
                for c, msk, i, yy, pp in zip(cams, mask[:, 0].numpy(), idx.numpy(), y.numpy(), pred):
                    S.append(scores(c, msk))
                    if k == 0 and b < 8:                       # keep a few maps for the figure only
                        examples.setdefault(int(i), {})[key] = c.astype(np.float16)
            del m, gc, layer
            _gc.collect()
            if dev.type == "cuda":
                torch.cuda.empty_cache()
        if S:
            S = np.array(S)
            R[f"XAI_{key}_IOU"] = f"{S[:, 0].mean():.3f} ± {S[:, 0].std(ddof=1):.3f}"
            R[f"XAI_{key}_PG"] = f"{100 * S[:, 1].mean():.2f}"
            R[f"XAI_{key}_EPG"] = f"{S[:, 2].mean():.3f} ± {S[:, 2].std(ddof=1):.3f}"
            print(key, R[f"XAI_{key}_IOU"], R[f"XAI_{key}_PG"], R[f"XAI_{key}_EPG"])

    # qualitative figure: two examples per class with all available models
    keys = [k for k in MODELS if any(k in e for e in examples.values())]
    full = [i for i, e in examples.items() if all(k in e for k in keys)]
    pick = []
    for c in range(3):
        cand = [i for i in full if data["labels"][i] == c]
        pick += cand[:2]
    if pick:
        fig, axs = plt.subplots(len(pick), len(keys) + 1, figsize=(2.3 * (len(keys) + 1), 2.3 * len(pick)))
        axs = np.atleast_2d(axs)
        for r, i in enumerate(pick):
            img = cv2.resize(data["imgs"][i].astype(np.float32), (224, 224))
            msk = cv2.resize(data["masks"][i], (224, 224), interpolation=cv2.INTER_NEAREST)
            axs[r, 0].imshow(img, cmap="gray"); axs[r, 0].contour(msk, [0.5], colors="lime", linewidths=1)
            axs[r, 0].set_title(CLASS_NAMES[data["labels"][i]], fontsize=8)
            for c, k in enumerate(keys):
                axs[r, c + 1].imshow(img, cmap="gray"); axs[r, c + 1].imshow(examples[i][k].astype(np.float32), cmap="jet", alpha=0.45)
                axs[r, c + 1].contour(msk, [0.5], colors="white", linewidths=0.8)
                if r == 0:
                    axs[r, c + 1].set_title(k, fontsize=8)
        for ax in axs.flat:
            ax.axis("off")
        plt.tight_layout(); os.makedirs(os.path.join(a.out, "figs"), exist_ok=True)
        plt.savefig(os.path.join(a.out, "figs", "gradcam_examples.png"), dpi=300); plt.close()

    path = os.path.join(a.out, "results.json")
    old = json.load(open(path)) if os.path.exists(path) else {}
    old.update(R); json.dump(old, open(path, "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
