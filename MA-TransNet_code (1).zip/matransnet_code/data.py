"""Figshare brain-tumour dataset (Cheng et al., 2015) loading, patient-wise folds and augmentation.

The dataset consists of 3,064 T1-weighted contrast-enhanced (CE-T1w) slices from 233 patients:
label 1 = meningioma (708), 2 = glioma (1,426), 3 = pituitary tumour (930).
Each .mat file (MATLAB v7.3 / HDF5) stores cjdata.{image, label, PID, tumorMask, tumorBorder}.
`cvind.mat` provides the official patient-wise 5-fold partition.
"""
import glob
import os

import cv2
import h5py
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

CLASS_NAMES = ["Meningioma", "Glioma", "Pituitary"]
CLASS_KEYS = ["MEN", "GLI", "PIT"]


def _read_mat(path):
    with h5py.File(path, "r") as h:
        c = h["cjdata"]
        img = np.array(c["image"]).T.astype(np.float32)        # MATLAB column-major -> row-major
        mask = np.array(c["tumorMask"]).T.astype(np.uint8)
        label = int(np.array(c["label"]).item()) - 1             # 0,1,2
        pid = "".join(chr(int(x)) for x in np.array(c["PID"]).flatten())
    return img, mask, label, pid


def robust_normalise(img, lo=0.5, hi=99.5):
    """Percentile clipping + min-max to [0, 1] (per image, no cross-sample statistics)."""
    a, b = np.percentile(img, [lo, hi])
    img = np.clip(img, a, b)
    return (img - a) / max(b - a, 1e-6)


def apply_clahe(img01, clip=2.0, tiles=8):
    u8 = (img01 * 255).astype(np.uint8)
    out = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tiles, tiles)).apply(u8)
    return out.astype(np.float32) / 255.0


def build_cache(data_dir, cache_path, size=256, clahe=True):
    """Reads all .mat files once and stores resized images/masks in a compressed .npz."""
    files = sorted(glob.glob(os.path.join(data_dir, "**", "*.mat"), recursive=True),
                   key=lambda f: os.path.basename(f))
    files = [f for f in files if os.path.basename(f)[:-4].isdigit()]
    files = sorted(files, key=lambda f: int(os.path.basename(f)[:-4]))
    imgs, masks, labels, pids, idx = [], [], [], [], []
    for f in files:
        img, mask, label, pid = _read_mat(f)
        img = robust_normalise(img)
        if clahe:
            img = apply_clahe(img)
        img = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
        mask = cv2.resize(mask, (size, size), interpolation=cv2.INTER_NEAREST)
        imgs.append(img.astype(np.float16)); masks.append(mask); labels.append(label)
        pids.append(pid); idx.append(int(os.path.basename(f)[:-4]))
    np.savez_compressed(cache_path, imgs=np.stack(imgs), masks=np.stack(masks),
                        labels=np.array(labels), pids=np.array(pids), idx=np.array(idx))
    return cache_path


def load_cache(data_dir, size=256, clahe=True):
    cache = os.path.join(data_dir, f"cache_{size}_{'clahe' if clahe else 'raw'}.npz")
    if not os.path.exists(cache):
        print(f"[data] building cache -> {cache}")
        build_cache(data_dir, cache, size, clahe)
    d = np.load(cache, allow_pickle=False)
    return {k: d[k] for k in d.files}


def load_folds(data_dir, labels, pids, idx, n_folds=5, seed=0):
    """Returns fold id (0..4) for every sample.

    Uses the official `cvind.mat` patient-wise partition when present; otherwise falls back to a
    StratifiedGroupKFold over patient IDs (still patient-disjoint)."""
    cv = os.path.join(data_dir, "cvind.mat")
    if os.path.exists(cv):
        try:
            with h5py.File(cv, "r") as h:
                folds = np.array(h["cvind"]).flatten().astype(int)
        except OSError:
            from scipy.io import loadmat
            folds = loadmat(cv)["cvind"].flatten().astype(int)
        folds = folds[idx - 1] - 1                  # align with the file indices actually loaded
        print("[data] using official cvind.mat patient-wise folds")
    else:
        from sklearn.model_selection import StratifiedGroupKFold
        folds = np.zeros(len(labels), dtype=int)
        sgkf = StratifiedGroupKFold(n_splits=n_folds, shuffle=True, random_state=seed)
        for k, (_, te) in enumerate(sgkf.split(np.zeros(len(labels)), labels, groups=pids)):
            folds[te] = k
        print("[data] cvind.mat not found -> StratifiedGroupKFold on patient IDs")
    # sanity check: no patient in more than one fold
    for p in np.unique(pids):
        assert len(np.unique(folds[pids == p])) == 1, f"patient {p} spans several folds (leakage)"
    return folds


def split_indices(folds, test_fold, n_folds=5):
    """Patient-wise split: test = fold k, validation = fold (k+1) mod K, training = remaining folds."""
    val_fold = (test_fold + 1) % n_folds
    te = np.where(folds == test_fold)[0]
    va = np.where(folds == val_fold)[0]
    tr = np.where((folds != test_fold) & (folds != val_fold))[0]
    return tr, va, te


# ----------------------------------------------------------------------------------------------
# Augmentation (training only). Implemented on tensors so that it runs on CPU workers.
# ----------------------------------------------------------------------------------------------
def _affine(x, deg, trans, scale, flip):
    theta = np.deg2rad(deg)
    cos, sin = np.cos(theta) / scale, np.sin(theta) / scale
    m = torch.tensor([[cos * (-1 if flip else 1), -sin, trans[0]],
                      [sin * (-1 if flip else 1), cos, trans[1]]], dtype=torch.float32)
    grid = F.affine_grid(m[None], x[None].shape, align_corners=False)
    return F.grid_sample(x[None], grid, mode="bilinear", padding_mode="zeros", align_corners=False)[0]


def _elastic(x, alpha=30.0, sigma=5.0):
    _, h, w = x.shape
    dx = cv2.GaussianBlur((np.random.rand(h, w) * 2 - 1).astype(np.float32), (0, 0), sigma) * alpha
    dy = cv2.GaussianBlur((np.random.rand(h, w) * 2 - 1).astype(np.float32), (0, 0), sigma) * alpha
    yy, xx = np.meshgrid(np.linspace(-1, 1, h), np.linspace(-1, 1, w), indexing="ij")
    grid = np.stack([xx + dx * 2 / w, yy + dy * 2 / h], -1).astype(np.float32)
    return F.grid_sample(x[None], torch.from_numpy(grid)[None], align_corners=False)[0]


class Augment:
    def __init__(self, p_flip=0.5, p_rot=0.7, p_aff=0.5, p_elastic=0.3, p_noise=0.3, p_gamma=0.3):
        self.p = dict(flip=p_flip, rot=p_rot, aff=p_aff, el=p_elastic, noise=p_noise, gamma=p_gamma)

    def __call__(self, x):
        r = np.random.rand
        flip = r() < self.p["flip"]
        deg = np.random.uniform(-10, 10) if r() < self.p["rot"] else 0.0
        if r() < self.p["aff"]:
            trans = np.random.uniform(-0.1, 0.1, 2) * 2
            scale = np.random.uniform(0.9, 1.1)
        else:
            trans, scale = (0.0, 0.0), 1.0
        if flip or deg or scale != 1.0 or trans[0] or trans[1]:
            x = _affine(x, deg, trans, scale, flip)
        if r() < self.p["el"]:
            x = _elastic(x)
        if r() < self.p["gamma"]:
            x = x.clamp(0, 1) ** np.random.uniform(0.8, 1.25)
        if r() < self.p["noise"]:
            x = x + torch.randn_like(x) * np.random.uniform(0.0, 0.03)
        return x


class FigshareDataset(Dataset):
    def __init__(self, data, indices, img_size=224, train=False, mean=None, std=None):
        self.imgs, self.masks = data["imgs"], data["masks"]
        self.labels, self.pids = data["labels"], data["pids"]
        self.ind = np.asarray(indices)
        self.size, self.train = img_size, train
        self.aug = Augment() if train else None
        self.mean = float(mean) if mean is not None else 0.0
        self.std = float(std) if std is not None else 1.0

    def __len__(self):
        return len(self.ind)

    def __getitem__(self, i):
        j = self.ind[i]
        x = torch.from_numpy(self.imgs[j].astype(np.float32))[None]
        m = torch.from_numpy(self.masks[j].astype(np.float32))[None]
        if self.train:
            x = self.aug(x)
        x = F.interpolate(x[None], size=(self.size, self.size), mode="bilinear", align_corners=False)[0]
        m = F.interpolate(m[None], size=(self.size, self.size), mode="nearest")[0]
        x = (x - self.mean) / self.std                       # training-fold statistics only
        return x, int(self.labels[j]), m, int(j)


def train_stats(data, tr_idx):
    v = data["imgs"][tr_idx].astype(np.float32)
    return float(v.mean()), float(v.std())


def cutmix(x, y_onehot, alpha=1.0):
    lam = np.random.beta(alpha, alpha)
    perm = torch.randperm(x.size(0), device=x.device)
    h, w = x.shape[-2:]
    rh, rw = int(h * np.sqrt(1 - lam)), int(w * np.sqrt(1 - lam))
    cy, cx = np.random.randint(h), np.random.randint(w)
    y1, y2 = np.clip(cy - rh // 2, 0, h), np.clip(cy + rh // 2, 0, h)
    x1, x2 = np.clip(cx - rw // 2, 0, w), np.clip(cx + rw // 2, 0, w)
    x = x.clone()
    x[..., y1:y2, x1:x2] = x[perm][..., y1:y2, x1:x2]
    lam = 1 - (y2 - y1) * (x2 - x1) / (h * w)
    return x, lam * y_onehot + (1 - lam) * y_onehot[perm]
