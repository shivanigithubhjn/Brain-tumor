#!/usr/bin/env bash
# Full experimental protocol of the manuscript.
#   DATA = folder containing 1.mat ... 3064.mat and cvind.mat (Figshare, all four zip parts)
# Approximate cost on one NVIDIA T4 (16 GB): main comparison ~ 25-30 GPU-h (3 seeds),
# ablations ~ 15 GPU-h (1 seed). Reduce SEEDS / comment out blocks if needed.
set -e
DATA=${DATA:-./figshare}
OUT=${OUT:-runs}
SEEDS=${SEEDS:-"0 1 2"}
ABL_SEEDS=${ABL_SEEDS:-"0"}

# 1) Main comparison: proposed model (DWFL + consistency) vs. nine ImageNet-pretrained baselines (CE)
for s in $SEEDS; do for f in 0 1 2 3 4; do
  python train.py --data_dir $DATA --out $OUT --model matransnet --fold $f --seed $s
  for b in resnet50 densenet121 efficientnet_b0 mobilenetv3 convnext_tiny vit_small deit_small swin_tiny maxvit_tiny; do
    python train.py --data_dir $DATA --out $OUT --model $b --fold $f --seed $s
  done
done; done

# 2) Architectural ablations
for s in $ABL_SEEDS; do for f in 0 1 2 3 4; do
  for v in no_gaam no_gate attn_full attn_window no_gsb no_ltb no_msfa msfa_concat; do
    python train.py --data_dir $DATA --out $OUT --model matransnet --variant $v --fold $f --seed $s
  done
  # 3) Optimisation ablations
  python train.py --data_dir $DATA --out $OUT --model matransnet --cons 0 --fold $f --seed $s
  for l in ce wce focal cbfocal dwfl_nofreq dwfl_nodiff; do
    python train.py --data_dir $DATA --out $OUT --model matransnet --loss $l --fold $f --seed $s
  done
done; done

# 4) Analysis
python evaluate.py   --runs $OUT --out results
python xai.py        --runs $OUT --data_dir $DATA --out results
python robustness.py --runs $OUT --data_dir $DATA --out results
python efficiency.py --out results
python fill_results.py --docx MA-TransNet_manuscript.docx --results results/results.json \
                       --out MA-TransNet_manuscript_filled.docx
