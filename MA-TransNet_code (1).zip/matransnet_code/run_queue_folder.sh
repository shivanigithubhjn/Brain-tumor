#!/usr/bin/env bash
# Compact CPU protocol on the 15-class folder dataset (from scratch, 128 px, group-stratified 70/10/20 split).
cd /home/claude/matransnet_code
C="--dataset folder --data_dir /tmp/claude-0/-home-claude/aff48614-4275-57d3-8d16-ffca7dc1ee48/scratchpad/bt21/raw --cache_dir /tmp/claude-0/-home-claude/aff48614-4275-57d3-8d16-ffca7dc1ee48/scratchpad/exp/cache --out /tmp/claude-0/-home-claude/aff48614-4275-57d3-8d16-ffca7dc1ee48/scratchpad/exp/runs --img 128 --epochs 25 --patience 8 --warmup 2 --bs 32 --workers 0 --no_pretrained --threads 2 --lr 1e-3"
M="--model matransnet --size small"
jobs=(
 "$M"
 "--model resnet18" "--model convnext_atto" "--model deit_tiny" "--model mobilenetv3" "--model efficientnet_b0"
 "$M --variant no_gaam" "$M --loss ce" "$M --cons 0" "$M --variant attn_full" "$M --variant no_gsb"
 "$M --variant no_msfa" "$M --variant no_gate" "$M --loss cbfocal"
 "$M --orig_split" "$M --seed 1" "$M --seed 2"
)
for j in "${jobs[@]}"; do
  eval python3 train.py $C $j 2>&1 | grep -v -i warn | grep -E "train |ep 0[0-9][0-9]|done|resumed|already|early|Error|Traceback" 
done
