"""Aggregate all runs into metrics, statistics, figures and `results/results.json`.

The JSON keys match the ⟦KEY⟧ placeholders in the manuscript; `fill_results.py` substitutes them.
Usage: python evaluate.py --runs runs --data_dir ./figshare --out results
"""
import argparse
import glob
import json
import os
import re
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import binomtest, wilcoxon
from sklearn.metrics import (accuracy_score, cohen_kappa_score, confusion_matrix, f1_score,
                             matthews_corrcoef, precision_score, recall_score, roc_auc_score, roc_curve)

from data import CLASS_KEYS, CLASS_NAMES

PROPOSED = "matransnet_full_dwfl_c0.5"
BASELINE_KEYS = {"resnet50": "RESNET50", "densenet121": "DENSENET121", "efficientnet_b0": "EFFB0",
                 "mobilenetv3": "MOBILENETV3", "convnext_tiny": "CONVNEXT", "vit_small": "VITS",
                 "deit_small": "DEITS", "swin_tiny": "SWINT", "maxvit_tiny": "MAXVIT"}
PRETTY = {"RESNET50": "ResNet-50", "DENSENET121": "DenseNet-121", "EFFB0": "EfficientNet-B0",
          "MOBILENETV3": "MobileNetV3-L", "CONVNEXT": "ConvNeXt-T", "VITS": "ViT-S/16", "DEITS": "DeiT-S",
          "SWINT": "Swin-T", "MAXVIT": "MaxViT-T"}
ABLATION_GROUPS = {
    "FULL": PROPOSED,
    "NO_GAAM": "matransnet_no_gaam_dwfl_c0.5", "NO_GATE": "matransnet_no_gate_dwfl_c0.5",
    "ATTN_FULL": "matransnet_attn_full_dwfl_c0.5", "ATTN_WINDOW": "matransnet_attn_window_dwfl_c0.5",
    "NO_GSB": "matransnet_no_gsb_dwfl_c0.5", "NO_LTB": "matransnet_no_ltb_dwfl_c0.5",
    "NO_MSFA": "matransnet_no_msfa_dwfl_c0.5", "MSFA_CONCAT": "matransnet_msfa_concat_dwfl_c0.5",
    "NO_CONS": "matransnet_full_dwfl_c0",
    "LOSS_CE": "matransnet_full_ce_c0.5", "LOSS_WCE": "matransnet_full_wce_c0.5",
    "LOSS_FOCAL": "matransnet_full_focal_c0.5", "LOSS_CBFOCAL": "matransnet_full_cbfocal_c0.5",
    "DWFL_NOFREQ": "matransnet_full_dwfl_nofreq_c0.5", "DWFL_NODIFF": "matransnet_full_dwfl_nodiff_c0.5",
}
METRICS = ["ACC", "PREC", "REC", "SPEC", "F1", "AUC", "MCC", "KAPPA", "BACC"]


def specificity_macro(y, yp, K=3):
    cm = confusion_matrix(y, yp, labels=range(K))
    sp = []
    for k in range(K):
        tn = cm.sum() - cm[k, :].sum() - cm[:, k].sum() + cm[k, k]
        fp = cm[:, k].sum() - cm[k, k]
        sp.append(tn / max(tn + fp, 1))
    return float(np.mean(sp)), sp


def safe_auc(y, p, **kw):
    try:
        return roc_auc_score(y, p, **kw)
    except ValueError:
        return float("nan")


def metrics(p, y):
    yp = p.argmax(1)
    return {"ACC": accuracy_score(y, yp), "PREC": precision_score(y, yp, average="macro", zero_division=0),
            "REC": recall_score(y, yp, average="macro", zero_division=0),
            "SPEC": specificity_macro(y, yp)[0], "F1": f1_score(y, yp, average="macro", zero_division=0),
            "AUC": safe_auc(y, p, multi_class="ovr", average="macro", labels=[0, 1, 2]),
            "MCC": matthews_corrcoef(y, yp), "KAPPA": cohen_kappa_score(y, yp),
            "BACC": recall_score(y, yp, average="macro", zero_division=0)}


def fmt(vals, metric):
    v = np.asarray(vals, dtype=float)
    v = v[~np.isnan(v)]
    if len(v) == 0:
        return "n/a"
    if metric in ("AUC", "MCC", "KAPPA"):
        return f"{v.mean():.4f} ± {v.std(ddof=1) if len(v) > 1 else 0:.4f}"
    return f"{100 * v.mean():.2f} ± {100 * (v.std(ddof=1) if len(v) > 1 else 0):.2f}"


def fmt_p(p):
    return "< 0.001" if p < 0.001 else f"{p:.3f}"


def load_runs(runs_dir):
    groups = defaultdict(dict)   # group -> {(fold, seed): (probs, labels, idx, pids)}
    for f in glob.glob(os.path.join(runs_dir, "*", "pred_test.npz")):
        tag = os.path.basename(os.path.dirname(f))
        m = re.match(r"(.+)_f(\d+)_s(\d+)$", tag)
        if not m:
            continue
        d = np.load(f, allow_pickle=True)
        groups[m.group(1)][(int(m.group(2)), int(m.group(3)))] = (d["probs"], d["labels"], d["idx"], d["pids"])
    return groups


def pooled(group, seed):
    parts = [v for (f, s), v in sorted(group.items()) if s == seed]
    p = np.concatenate([x[0] for x in parts]); y = np.concatenate([x[1] for x in parts])
    idx = np.concatenate([x[2] for x in parts]); pid = np.concatenate([x[3] for x in parts])
    o = np.argsort(idx)
    return p[o], y[o], idx[o], pid[o]


def cluster_bootstrap_ci(p, y, pid, fn, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    up = np.unique(pid)
    rows = {u: np.where(pid == u)[0] for u in up}
    stats = []
    for _ in range(n):
        sel = np.concatenate([rows[u] for u in rng.choice(up, len(up), replace=True)])
        try:
            stats.append(fn(p[sel], y[sel]))
        except ValueError:
            pass
    stats = [x for x in stats if not np.isnan(x)]
    return np.percentile(stats, [2.5, 97.5]) if stats else (float("nan"), float("nan"))


def mcnemar_exact(y, a, b):
    ca, cb = a == y, b == y
    n01, n10 = int((ca & ~cb).sum()), int((~ca & cb).sum())
    if n01 + n10 == 0:
        return 1.0
    return binomtest(n01, n01 + n10, 0.5).pvalue


def holm(pvals):
    keys = sorted(pvals, key=pvals.get)
    m, out, prev = len(keys), {}, 0.0
    for i, k in enumerate(keys):
        adj = min(1.0, max(prev, (m - i) * pvals[k]))
        out[k] = adj; prev = adj
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", default="results")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "figs"), exist_ok=True)
    R = {}
    G = load_runs(a.runs)
    print("groups found:", {k: len(v) for k, v in G.items()})
    per_run = {g: [metrics(v[0], v[1]) for v in runs.values()] for g, runs in G.items()}

    # ---------------- comparison table ----------------
    comp = {k: f"{b}_full_ce_c0" for b, k in BASELINE_KEYS.items()}
    comp["MATRANSNET"] = PROPOSED
    for key, g in comp.items():
        if g not in per_run:
            continue
        for m in METRICS:
            R[f"CMP_{key}_{m}"] = fmt([r[m] for r in per_run[g]], m)
        R[f"CMP_{key}_NRUNS"] = str(len(per_run[g]))

    if PROPOSED in G:
        g = G[PROPOSED]
        seeds = sorted({s for _, s in g})
        R["N_SEEDS"] = str(len(seeds))
        for m in METRICS:
            v = np.array([r[m] for r in per_run[PROPOSED]])
            v = v[~np.isnan(v)]
            sd = v.std(ddof=1) if len(v) > 1 else 0.0
            R[f"MAIN_{m}"] = (f"{100 * v.mean():.2f}" if m not in ("AUC", "MCC", "KAPPA") else f"{v.mean():.4f}")
            R[f"MAIN_{m}_SD"] = (f"{100 * sd:.2f}" if m not in ("AUC", "MCC", "KAPPA") else f"{sd:.4f}")
        # pooled out-of-fold, seed 0: CIs, per-class, confusion matrix, patient level
        p, y, idx, pid = pooled(g, seeds[0])
        lo, hi = cluster_bootstrap_ci(p, y, pid, lambda P, Y: accuracy_score(Y, P.argmax(1)))
        R["MAIN_ACC_CI"] = f"{100 * lo:.2f}–{100 * hi:.2f}"
        lo, hi = cluster_bootstrap_ci(p, y, pid, lambda P, Y: safe_auc(Y, P, multi_class="ovr", labels=[0, 1, 2]))
        R["MAIN_AUC_CI"] = f"{lo:.4f}–{hi:.4f}"
        lo, hi = cluster_bootstrap_ci(p, y, pid, lambda P, Y: f1_score(Y, P.argmax(1), average="macro"))
        R["MAIN_F1_CI"] = f"{100 * lo:.2f}–{100 * hi:.2f}"
        # per-class (mean ± sd over seeds of pooled OOF)
        pcs = defaultdict(list)
        cm_sum = np.zeros((3, 3))
        pat_acc, pat_f1 = [], []
        for s in seeds:
            p, y, idx, pid = pooled(g, s)
            yp = p.argmax(1)
            cm_sum += confusion_matrix(y, yp, labels=range(3))
            prec = precision_score(y, yp, average=None, labels=range(3), zero_division=0)
            rec = recall_score(y, yp, average=None, labels=range(3), zero_division=0)
            f1 = f1_score(y, yp, average=None, labels=range(3), zero_division=0)
            spec = specificity_macro(y, yp)[1]
            for k in range(3):
                auc = safe_auc((y == k).astype(int), p[:, k])
                for nm, val in (("PREC", prec[k]), ("REC", rec[k]), ("SPEC", spec[k]), ("F1", f1[k]), ("AUC", auc)):
                    pcs[(k, nm)].append(val)
            # patient-level: mean slice probability per patient
            up = np.unique(pid)
            pp = np.stack([p[pid == u].mean(0) for u in up]); py = np.array([y[pid == u][0] for u in up])
            pat_acc.append(accuracy_score(py, pp.argmax(1))); pat_f1.append(f1_score(py, pp.argmax(1), average="macro"))
        for (k, nm), vals in pcs.items():
            R[f"PC_{CLASS_KEYS[k]}_{nm}"] = fmt(vals, nm)
        R["PAT_ACC"] = fmt(pat_acc, "ACC"); R["PAT_F1"] = fmt(pat_f1, "F1")
        R["N_PATIENTS_EVAL"] = str(len(np.unique(pid)))
        cmn = cm_sum / cm_sum.sum(1, keepdims=True)
        fig, ax = plt.subplots(figsize=(4.6, 4))
        im = ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, f"{100 * cmn[i, j]:.2f}%\n({int(cm_sum[i, j])})", ha="center", va="center",
                        color="white" if cmn[i, j] > 0.5 else "black", fontsize=8)
        ax.set_xticks(range(3), CLASS_NAMES); ax.set_yticks(range(3), CLASS_NAMES)
        ax.set_xlabel("Predicted class"); ax.set_ylabel("True class"); plt.colorbar(im, fraction=0.046)
        plt.tight_layout(); plt.savefig(os.path.join(a.out, "figs", "confusion_matrix.png"), dpi=300); plt.close()

        # ROC curves (pooled OOF, seed 0): per class for proposed + macro for all models
        p, y, _, _ = pooled(g, seeds[0])
        fig, axs = plt.subplots(1, 2, figsize=(10, 4.2))
        for k in range(3):
            fpr, tpr, _ = roc_curve((y == k).astype(int), p[:, k])
            axs[0].plot(fpr, tpr, label=f"{CLASS_NAMES[k]} (AUC={safe_auc((y == k).astype(int), p[:, k]):.4f})")
        axs[0].plot([0, 1], [0, 1], "k--", lw=0.8); axs[0].set_title("MA-TransNet: one-vs-rest ROC")
        for key, gname in comp.items():
            if gname not in G:
                continue
            ss = sorted({s for _, s in G[gname]})
            pp, yy, _, _ = pooled(G[gname], ss[0])
            grid = np.linspace(0, 1, 200); tprs = []
            for k in range(3):
                fpr, tpr, _ = roc_curve((yy == k).astype(int), pp[:, k]); tprs.append(np.interp(grid, fpr, tpr))
            axs[1].plot(grid, np.mean(tprs, 0), lw=2.2 if key == "MATRANSNET" else 1,
                        label=f"{key} ({safe_auc(yy, pp, multi_class='ovr', labels=[0, 1, 2]):.4f})")
        axs[1].plot([0, 1], [0, 1], "k--", lw=0.8); axs[1].set_title("Macro-average ROC (all models)")
        for ax_ in axs:
            ax_.set_xlabel("False positive rate"); ax_.set_ylabel("True positive rate"); ax_.legend(fontsize=7)
        plt.tight_layout(); plt.savefig(os.path.join(a.out, "figs", "roc_curves.png"), dpi=300); plt.close()

        # ---------------- statistics vs baselines ----------------
        p0, y0, idx0, _ = pooled(g, seeds[0])
        raw_mcn, raw_wil = {}, {}
        for b, key in BASELINE_KEYS.items():
            gb = f"{b}_full_ce_c0"
            if gb not in G:
                continue
            sb = sorted({s for _, s in G[gb]})
            pb, yb, idxb, _ = pooled(G[gb], sb[0])
            assert np.array_equal(idx0, idxb)
            raw_mcn[key] = mcnemar_exact(y0, p0.argmax(1), pb.argmax(1))
            common = sorted(set(G[PROPOSED]) & set(G[gb]))
            da = [metrics(*G[PROPOSED][c][:2])["ACC"] - metrics(*G[gb][c][:2])["ACC"] for c in common]
            R[f"STAT_{key}_DACC"] = f"{100 * np.mean(da):+.2f} ± {100 * np.std(da, ddof=1) if len(da) > 1 else 0:.2f}"
            try:
                raw_wil[key] = wilcoxon(da).pvalue if np.any(np.array(da) != 0) else 1.0
            except ValueError:
                raw_wil[key] = 1.0
        for key, pv in holm(raw_mcn).items():
            R[f"STAT_{key}_MCN_P"] = fmt_p(pv)
        for key, pv in holm(raw_wil).items():
            R[f"STAT_{key}_WIL_P"] = fmt_p(pv)
        # strongest baseline (highest mean accuracy) for the abstract / results text
        bl = {key: np.mean([r["ACC"] for r in per_run[f"{b}_full_ce_c0"]])
              for b, key in BASELINE_KEYS.items() if f"{b}_full_ce_c0" in per_run}
        if bl:
            kb = max(bl, key=bl.get)
            R["BEST_BASELINE"] = PRETTY[kb]
            R["BEST_BASELINE_ACC"] = R[f"CMP_{kb}_ACC"]
            R["BEST_DACC"] = R.get(f"STAT_{kb}_DACC", "n/a")
            R["BEST_WIL_P"] = R.get(f"STAT_{kb}_WIL_P", "n/a")
            R["BEST_MCN_P"] = R.get(f"STAT_{kb}_MCN_P", "n/a")
        # mean wall-clock time per epoch of the proposed model
        ts = [np.mean([h["time_s"] for h in json.load(open(f))])
              for f in glob.glob(os.path.join(a.runs, f"{PROPOSED}_f*_s*", "history.json"))]
        if ts:
            R["TIME_EPOCH"] = f"{np.mean(ts):.1f}"

        # training curves + DWFL weights (fold 0, seed 0)
        hfile = os.path.join(a.runs, f"{PROPOSED}_f0_s{seeds[0]}", "history.json")
        if os.path.exists(hfile):
            h = json.load(open(hfile))
            fig, axs = plt.subplots(1, 3, figsize=(13, 3.6))
            ep = [r["epoch"] for r in h]
            axs[0].plot(ep, [r["train_loss"] for r in h], label="train DWFL"); axs[0].plot(ep, [r["val_loss"] for r in h], label="val NLL")
            axs[0].legend(); axs[0].set_title("Loss")
            axs[1].plot(ep, [r["val_acc"] for r in h], label="val accuracy"); axs[1].plot(ep, [r["val_auc"] for r in h], label="val macro-AUC")
            axs[1].legend(); axs[1].set_title("Validation")
            if "dwfl_beta" in h[0]:
                B = np.array([r["dwfl_beta"] for r in h])
                for k in range(3):
                    axs[2].plot(ep, B[:, k], label=CLASS_NAMES[k])
                axs[2].legend(); axs[2].set_title(r"DWFL class weights $\beta_k(t)$")
            for ax_ in axs:
                ax_.set_xlabel("Epoch")
            plt.tight_layout(); plt.savefig(os.path.join(a.out, "figs", "training_curves.png"), dpi=300); plt.close()

    # ---------------- ablation ----------------
    for key, gname in ABLATION_GROUPS.items():
        if gname in per_run:
            for m in ("ACC", "F1", "AUC", "MCC"):
                R[f"ABL_{key}_{m}"] = fmt([r[m] for r in per_run[gname]], m)
            if key != "FULL" and PROPOSED in per_run:
                common = sorted(set(G[PROPOSED]) & set(G[gname]))
                d = [metrics(*G[gname][c][:2])["ACC"] - metrics(*G[PROPOSED][c][:2])["ACC"] for c in common]
                R[f"ABL_{key}_DACC"] = f"{100 * np.mean(d):+.2f}"

    # merge with other result files
    path = os.path.join(a.out, "results.json")
    old = json.load(open(path)) if os.path.exists(path) else {}
    old.update(R)
    json.dump(old, open(path, "w"), indent=1, ensure_ascii=False)
    print(f"wrote {len(R)} keys -> {path}")


if __name__ == "__main__":
    main()
