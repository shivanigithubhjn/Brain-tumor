"""Losses: Dynamic Weighted Focal Loss (DWFL), consistency regularisation and comparison losses.

All losses accept either hard labels (B,) or soft targets (B, K) (used with CutMix).
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def to_onehot(y, K):
    return y if y.dim() == 2 else F.one_hot(y, K).float()


class DWFL(nn.Module):
    """Dynamic Weighted Focal Loss.

    beta_k(t) = f_k * d_k(t), with
      f_k   = N / (K n_k)                                   (static inverse-frequency term)
      d_k(t)= eps_k(t) / mean_j eps_j(t)                    (dynamic difficulty term)
      eps_k(t) = rho * eps_k(t-1) + (1 - rho) * L_k(t)       (EMA of the class-wise mean CE of epoch t)
    beta is renormalised so that sum_k pi_k beta_k = 1 (pi_k = n_k / N) to keep the loss scale fixed.
    """

    def __init__(self, class_counts, gamma=2.0, rho=0.9, use_freq=True, use_diff=True):
        super().__init__()
        n = torch.tensor(class_counts, dtype=torch.float32)
        self.K, self.gamma, self.rho = len(class_counts), gamma, rho
        self.use_freq, self.use_diff = use_freq, use_diff
        self.register_buffer("pi", n / n.sum())
        self.register_buffer("freq", n.sum() / (self.K * n))
        self.register_buffer("eps", torch.ones(self.K))
        self.register_buffer("acc", torch.zeros(self.K))
        self.register_buffer("cnt", torch.zeros(self.K))

    def weights(self):
        b = torch.ones(self.K, device=self.eps.device)
        if self.use_freq:
            b = b * self.freq
        if self.use_diff:
            b = b * self.eps / self.eps.mean().clamp_min(1e-8)
        return b / (self.pi * b).sum().clamp_min(1e-8)

    def forward(self, logits, y):
        t = to_onehot(y, self.K)
        logp = F.log_softmax(logits.float(), -1)
        p = logp.exp()
        focal = (1 - p).pow(self.gamma) * (-logp)
        loss = (t * self.weights()[None] * focal).sum(-1).mean()
        if self.training:
            with torch.no_grad():                       # class-wise CE statistics for the EMA
                self.acc += (t * -logp).sum(0)
                self.cnt += t.sum(0)
        return loss

    @torch.no_grad()
    def epoch_end(self):
        L = self.acc / self.cnt.clamp_min(1e-8)
        L = torch.where(self.cnt > 0, L, self.eps)
        self.eps.mul_(self.rho).add_((1 - self.rho) * L)
        self.acc.zero_(); self.cnt.zero_()


class WeightedFocal(nn.Module):
    """Generic (optionally class-weighted) focal / cross-entropy loss."""

    def __init__(self, K, weights=None, gamma=0.0):
        super().__init__()
        self.K, self.gamma = K, gamma
        self.register_buffer("w", torch.ones(K) if weights is None else torch.tensor(weights, dtype=torch.float32))

    def forward(self, logits, y):
        t = to_onehot(y, self.K)
        logp = F.log_softmax(logits.float(), -1)
        mod = (1 - logp.exp()).pow(self.gamma) if self.gamma > 0 else 1.0
        return (t * self.w[None] * mod * -logp).sum(-1).mean()

    def epoch_end(self):
        pass


def build_loss(name, class_counts, gamma=2.0, rho=0.9):
    K = len(class_counts)
    n = np.asarray(class_counts, dtype=np.float64)
    if name == "dwfl":
        return DWFL(class_counts, gamma, rho)
    if name == "dwfl_nofreq":
        return DWFL(class_counts, gamma, rho, use_freq=False)
    if name == "dwfl_nodiff":
        return DWFL(class_counts, gamma, rho, use_diff=False)
    if name == "ce":
        return WeightedFocal(K)
    if name == "wce":
        w = n.sum() / (K * n)
        return WeightedFocal(K, w / (n / n.sum() * w).sum())
    if name == "focal":
        return WeightedFocal(K, gamma=gamma)
    if name == "cbfocal":               # class-balanced focal loss (Cui et al., 2019), beta = 0.999
        beta = 0.999
        w = (1 - beta) / (1 - beta ** n)
        w = w / w.sum() * K
        return WeightedFocal(K, w, gamma=gamma)
    raise ValueError(name)


def consistency_loss(logits_clean, logits_pert):
    """KL( stopgrad(p(x)) || p(x') ), averaged over the batch."""
    p = F.softmax(logits_clean.detach().float(), -1)
    return F.kl_div(F.log_softmax(logits_pert.float(), -1), p, reduction="batchmean")


def consistency_weight(epoch, lam_max=0.5, ramp=10):
    if epoch >= ramp:
        return lam_max
    return lam_max * float(np.exp(-5 * (1 - epoch / ramp) ** 2))
