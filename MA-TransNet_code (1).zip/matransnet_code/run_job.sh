#!/usr/bin/env bash
# run_job.sh "<args1>" ["<args2>" ...] : runs one or more training jobs sequentially (resumable)
cd /home/claude/matransnet_code
S=/tmp/claude-0/-home-claude/aff48614-4275-57d3-8d16-ffca7dc1ee48/scratchpad
C="--dataset folder --data_dir $S/bt21/raw --cache_dir $S/exp/cache --out $S/exp/runs --img 128 --epochs 25 --patience 8 --warmup 2 --bs 32 --workers 0 --no_pretrained --threads 2 --lr 1e-3"
for j in "$@"; do
  python3 train.py $C $j 2>&1 | grep -v -i warn | grep -E "resumed|done|early|already|Error|Traceback"
done
