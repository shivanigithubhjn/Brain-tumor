"""Summarise group-wise 5-fold cross-validation (MA-TransNet-S vs ResNet-18) into results.json.
Usage: python cv_eval.py RUNS CACHE_DIR RESULTS_JSON"""
import glob, json, os, sys
import numpy as np
from scipy.stats import binomtest
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, roc_auc_score

runs, cache, out = sys.argv[1:4]
d = np.load(glob.glob(os.path.join(cache, "folder_cache_*.npz"))[0]); groups = d["groups"]; K = 15
M = {"MATRANSNET-S": "matransnet-S_full_ce_c0.5_cv{}_s0", "RESNET18": "resnet18_full_ce_c0_cv{}_s0"}
R, pooled = {}, {}
for key, pat in M.items():
    per, P, Y, I = [], [], [], []
    for k in range(5):
        f = os.path.join(runs, pat.format(k), "pred_test.npz")
        if not os.path.exists(f):
            continue
        z = np.load(f); p, y = z["probs"], z["labels"]; yp = p.argmax(1)
        per.append([accuracy_score(y, yp), balanced_accuracy_score(y, yp), f1_score(y, yp, average="macro"),
                    roc_auc_score(y, p, multi_class="ovr", labels=list(range(K)))])
        P.append(p); Y.append(y); I.append(z["idx"])
    R[f"CV_{key}_NFOLDS"] = str(len(per))
    if len(per) < 5:
        continue
    a = np.array(per)
    for j, m in enumerate(("ACC", "BACC", "F1")):
        R[f"CV_{key}_{m}"] = f"{100 * a[:, j].mean():.2f} ± {100 * a[:, j].std(ddof=1):.2f}"
    R[f"CV_{key}_AUC"] = f"{a[:, 3].mean():.4f} ± {a[:, 3].std(ddof=1):.4f}"
    p, y, idx = np.concatenate(P), np.concatenate(Y), np.concatenate(I); o = np.argsort(idx)
    pooled[key] = (p[o], y[o], idx[o], a[:, 0])
    g = groups[idx[o]]; ok = p[o].argmax(1) == y[o]; ug = np.unique(g); rows = {u: np.where(g == u)[0] for u in ug}
    rng = np.random.default_rng(0); bs = [ok[np.concatenate([rows[u] for u in rng.choice(ug, len(ug))])].mean() for _ in range(2000)]
    lo, hi = np.percentile(bs, [2.5, 97.5])
    R[f"CV_{key}_POOLED"] = f"{100 * ok.mean():.2f} ({100 * lo:.2f}–{100 * hi:.2f})"
if len(pooled) == 2:
    (pa, y, ia, fa), (pb, yb, ib, fb) = pooled["MATRANSNET-S"], pooled["RESNET18"]
    assert np.array_equal(ia, ib)
    ca, cb = pa.argmax(1) == y, pb.argmax(1) == y
    n01, n10 = int((ca & ~cb).sum()), int((~ca & cb).sum())
    pv = binomtest(n01, n01 + n10, 0.5).pvalue if n01 + n10 else 1.0
    g = groups[ia]; ug = np.unique(g); rows = {u: np.where(g == u)[0] for u in ug}; rng = np.random.default_rng(0)
    ds = []
    for _ in range(2000):
        s = np.concatenate([rows[u] for u in rng.choice(ug, len(ug))]); ds.append(ca[s].mean() - cb[s].mean())
    lo, hi = np.percentile(ds, [2.5, 97.5])
    R["CV_DACC"] = f"{100 * (ca.mean() - cb.mean()):+.2f}"; R["CV_DCI"] = f"{100 * lo:+.2f} to {100 * hi:+.2f}"
    R["CV_MCN_P"] = "< 0.001" if pv < 0.001 else f"{pv:.3f}"; R["CV_WIN"] = str(int((fa > fb).sum()))
    robust = pv < 0.05 and (lo > 0 or hi < 0)        # require McNemar AND group-bootstrap CI to agree
    if pv < 0.05 and not robust:
        R["CV_VERDICT"] = ("The image-level McNemar test favoured " + ("MA-TransNet-S" if ca.mean() > cb.mean() else "ResNet-18") +
                           ", but the group-bootstrap interval, which accounts for the dependence between images of the same duplicate group, includes zero; "
                           "we therefore interpret the two models as performing on par, with MA-TransNet-S using about half the parameters and computation.")
    elif not robust:
        R["CV_VERDICT"] = ("The difference was not statistically significant, confirming on all 4,264 images that MA-TransNet-S performs on par with ResNet-18 "
                           "while using about half its parameters and computation.")
    elif ca.mean() > cb.mean():
        R["CV_VERDICT"] = "MA-TransNet-S was significantly more accurate than ResNet-18 over the pooled cross-validation predictions."
    else:
        R["CV_VERDICT"] = ("ResNet-18 was significantly more accurate than MA-TransNet-S over the pooled cross-validation predictions, "
                           "so the parity observed on the single split does not generalize across folds; we report this as a limitation of the proposed architecture.")
old = json.load(open(out)); old.update(R); json.dump(old, open(out, "w"), indent=1, ensure_ascii=False)
print(json.dumps(R, indent=1, ensure_ascii=False))
