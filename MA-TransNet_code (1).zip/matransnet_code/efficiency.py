"""Parameters, FLOPs (fvcore, 1x1x224x224 input), batch-1 latency and peak training memory.

FLOPs are reported as fvcore counts (one fused multiply-add = 1 FLOP, i.e. GMACs).
Usage: python efficiency.py --out results           (GPU recommended for latency / memory)
"""
import argparse
import json
import os
import time

import torch
from fvcore.nn import FlopCountAnalysis

from model import ABLATIONS, build_model

KEYS = {"resnet50": "RESNET50", "densenet121": "DENSENET121", "efficientnet_b0": "EFFB0",
        "mobilenetv3": "MOBILENETV3", "convnext_tiny": "CONVNEXT", "vit_small": "VITS", "deit_small": "DEITS",
        "swin_tiny": "SWINT", "maxvit_tiny": "MAXVIT", "matransnet": "MATRANSNET"}
ABL_KEYS = {"full": "FULL", "no_gaam": "NO_GAAM", "no_gate": "NO_GATE", "attn_full": "ATTN_FULL",
            "attn_window": "ATTN_WINDOW", "no_gsb": "NO_GSB", "no_ltb": "NO_LTB", "no_msfa": "NO_MSFA",
            "msfa_concat": "MSFA_CONCAT"}


try:   # make timm use explicit attention matmuls so that fvcore counts them
    from timm.layers import set_fused_attn
    set_fused_attn(False)
except Exception:
    pass


def count(m, dev):
    m = m.to(dev).eval()
    x = torch.randn(1, 1, 224, 224, device=dev)
    params = sum(p.numel() for p in m.parameters()) / 1e6
    fl = FlopCountAnalysis(m, x); fl.unsupported_ops_warnings(False); fl.uncalled_modules_warnings(False)
    return params, fl.total() / 1e9


@torch.no_grad()
def latency(m, dev, n=100):
    m = m.to(dev).eval(); x = torch.randn(1, 1, 224, 224, device=dev)
    for _ in range(10):
        m(x)
    if dev.type == "cuda":
        torch.cuda.synchronize()
    t = time.perf_counter()
    for _ in range(n):
        m(x)
    if dev.type == "cuda":
        torch.cuda.synchronize()
    return (time.perf_counter() - t) / n * 1000


def train_mem(m, dev, bs=32):
    if dev.type != "cuda":
        return float("nan")
    m = m.to(dev).train(); torch.cuda.reset_peak_memory_stats()
    opt = torch.optim.AdamW(m.parameters())
    with torch.autocast("cuda"):
        loss = m(torch.randn(bs, 1, 224, 224, device=dev)).float().mean()
    loss.backward(); opt.step()
    return torch.cuda.max_memory_allocated() / 2 ** 30


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="results")
    ap.add_argument("--no_latency", action="store_true")
    a = ap.parse_args()
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    R, rows = {}, []
    for name, key in KEYS.items():
        m = build_model(name, pretrained=False)
        p, f = count(m, torch.device("cpu"))
        R[f"EFF_{key}_PARAMS"], R[f"EFF_{key}_FLOPS"] = f"{p:.2f}", f"{f:.2f}"
        if not a.no_latency:
            R[f"EFF_{key}_LAT"] = f"{latency(m, dev):.2f}"
            R[f"EFF_{key}_MEM"] = f"{train_mem(m, dev):.2f}"
        rows.append((key, p, f)); print(f"{key:12s} params {p:7.2f} M  FLOPs {f:6.2f} G")
    for v, key in ABL_KEYS.items():
        p, f = count(build_model("matransnet", pretrained=False, variant=v), torch.device("cpu"))
        R[f"ABL_{key}_PARAMS"], R[f"ABL_{key}_FLOPS"] = f"{p:.2f}", f"{f:.2f}"
        print(f"ablation {v:12s} params {p:7.2f} M  FLOPs {f:6.2f} G")
    R["EFF_DEVICE"] = torch.cuda.get_device_name(0) if dev.type == "cuda" else "CPU"
    R["HW_GPU"] = R["EFF_DEVICE"]
    R["SW_TORCH"] = torch.__version__.split("+")[0]
    import timm
    R["SW_TIMM"] = timm.__version__
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, "results.json")
    old = json.load(open(path)) if os.path.exists(path) else {}
    old.update(R); json.dump(old, open(path, "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
