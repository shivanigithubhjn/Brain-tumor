"""Folder-structured MRI dataset (train/<class>/*.jpg, test/<class>/*.jpg) with leakage control.

The provided train/test split of the 15-class collection contains exact and near-duplicate images
across the two folders. We therefore
  1. compute 64-bit perceptual hashes (pHash) of all images,
  2. drop images whose near-identical copy (Hamming distance <= 4) carries a different label,
  3. merge same-label images with Hamming distance <= 6 into duplicate groups (union-find),
  4. create a group-stratified split (StratifiedGroupKFold, 10 folds): 2 folds test (20%),
     1 fold validation (10%), 7 folds training (70%), so that no duplicate group crosses subsets.
"""
import glob
import json
import os

import numpy as np
from PIL import Image

EXTS = (".jpg", ".jpeg", ".png", ".webp", ".JPG", ".JPEG")


def list_images(root):
    files, labels = [], []
    classes = sorted({c for s in ("train", "test") if os.path.isdir(os.path.join(root, s))
                      for c in os.listdir(os.path.join(root, s)) if os.path.isdir(os.path.join(root, s, c))})
    for s in ("train", "test"):
        for k, c in enumerate(classes):
            for f in sorted(glob.glob(os.path.join(root, s, c, "*"))):
                if f.endswith(EXTS):
                    files.append(f); labels.append(k)
    return files, np.array(labels), classes


def pad_square_resize(img, size):
    img = img.convert("L")
    w, h = img.size
    s = max(w, h)
    canvas = Image.new("L", (s, s), 0)
    canvas.paste(img, ((s - w) // 2, (s - h) // 2))
    return canvas.resize((size, size), Image.BILINEAR)


def build_groups(files, labels, conflict_thr=4, group_thr=6):
    import imagehash
    H = np.stack([np.array(imagehash.phash(Image.open(f).convert("L"), hash_size=8).hash, dtype=np.uint8).flatten()
                  for f in files])
    D = (H[:, None, :] != H[None, :, :]).sum(-1)
    n = len(files)
    keep = np.ones(n, bool)
    i, j = np.where(np.triu(D <= conflict_thr, 1))
    for a, b in zip(i, j):
        if labels[a] != labels[b]:
            keep[a] = keep[b] = False
    par = list(range(n))

    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]; x = par[x]
        return x
    i, j = np.where(np.triu(D <= group_thr, 1))
    for a, b in zip(i, j):
        if keep[a] and keep[b] and labels[a] == labels[b]:
            par[find(a)] = find(b)
    groups = np.array([find(k) for k in range(n)])
    n_cross_exact = int(((D == 0) & np.triu(np.ones_like(D, bool), 1)).sum())
    return keep, groups, n_cross_exact


def load_folder(root, cache_dir, size=144, seed=0):
    os.makedirs(cache_dir, exist_ok=True)
    cache = os.path.join(cache_dir, f"folder_cache_{size}.npz")
    if not os.path.exists(cache):
        files, labels, classes = list_images(root)
        print(f"[data] {len(files)} images, {len(classes)} classes; hashing for duplicate control ...")
        keep, groups, _ = build_groups(files, labels)
        files = [f for f, k in zip(files, keep) if k]
        labels, groups = labels[keep], groups[keep]
        orig_split = np.array(["train" if os.sep + "train" + os.sep in f else "test" for f in files])
        imgs = np.stack([np.asarray(pad_square_resize(Image.open(f), size), dtype=np.float32) / 255.0
                         for f in files]).astype(np.float16)
        from sklearn.model_selection import StratifiedGroupKFold
        sgkf = StratifiedGroupKFold(n_splits=10, shuffle=True, random_state=seed)
        fold = np.zeros(len(files), int)
        for k, (_, te) in enumerate(sgkf.split(np.zeros(len(files)), labels, groups)):
            fold[te] = k
        subset = np.where(fold <= 1, "test", np.where(fold == 2, "val", "train"))
        np.savez_compressed(cache, imgs=imgs, labels=labels, groups=groups, subset=subset,
                            files=np.array(files), orig_split=orig_split, classes=np.array(classes),
                            n_dropped=np.array(int((~keep).sum())))
    d = np.load(cache, allow_pickle=False)
    data = {k: d[k] for k in d.files}
    data["pids"] = data["groups"].astype(str)            # duplicate group acts as the case identifier
    data["masks"] = np.zeros((len(data["labels"]), 1, 1), np.uint8)
    data["idx"] = np.arange(len(data["labels"]))
    for a in ("train", "val", "test"):
        for b in ("train", "val", "test"):
            if a < b:
                assert not (set(data["groups"][data["subset"] == a]) & set(data["groups"][data["subset"] == b])), \
                    f"duplicate group shared by {a} and {b}"
    return data
