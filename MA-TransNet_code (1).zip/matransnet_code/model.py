"""MA-TransNet: Multi-scale Axial-attention Transformer Network for brain-tumour MRI classification.

Pipeline:  input -> stem -> 4 x [DBRPE stage -> (GAAM)] -> MSFA -> DCH -> logits
  * DBRPE stage s: Local Texture Branch (LTB, residual basic blocks initialised from ResNet-34
    layer s) in parallel with a Global Structure Branch (GSB, dilated depthwise-separable convs);
    the two are fused by a 1x1 convolution with a residual connection to the LTB path.
  * GAAM: row-wise then column-wise multi-head self-attention with learnable 1-D relative
    position bias, a content-dependent spatial-channel gate and a convolutional feed-forward
    block, both residual with layer-scale (initialised to 0 so the pretrained path is preserved).
  * MSFA: per-scale 1x1 projection, resampling to a common grid, softmax scale attention and a
    1x1 fusion convolution.
  * DCH: global average pooling -> FC-BN-ReLU-Dropout -> FC.
Ablation switches are exposed through the constructor (see `build_model`).
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def conv_bn_act(cin, cout, k=3, s=1, d=1, groups=1, act=True):
    layers = [nn.Conv2d(cin, cout, k, s, padding=d * (k - 1) // 2, dilation=d, groups=groups, bias=False),
              nn.BatchNorm2d(cout)]
    if act:
        layers.append(nn.ReLU(inplace=True))
    return nn.Sequential(*layers)


# ----------------------------------------------------------------------------------------------
# Attention blocks
# ----------------------------------------------------------------------------------------------
class AxialAttention(nn.Module):
    """Multi-head self-attention along one spatial axis with learnable relative position bias."""

    def __init__(self, dim, heads=8, max_len=64, axis="w"):
        super().__init__()
        assert dim % heads == 0
        self.h, self.d, self.axis, self.max_len = heads, dim // heads, axis, max_len
        self.qkv = nn.Conv2d(dim, 3 * dim, 1, bias=False)
        self.out = nn.Conv2d(dim, dim, 1, bias=False)
        self.rel = nn.Parameter(torch.zeros(heads, 2 * max_len - 1))
        nn.init.trunc_normal_(self.rel, std=0.02)

    def forward(self, x):
        B, C, H, W = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=1)
        if self.axis == "w":   # attend across the width of every row
            def rs(t): return t.permute(0, 2, 3, 1).reshape(B * H, W, self.h, self.d).transpose(1, 2)
            L = W
        else:                  # attend across the height of every column
            def rs(t): return t.permute(0, 3, 2, 1).reshape(B * W, H, self.h, self.d).transpose(1, 2)
            L = H
        q, k, v = rs(q), rs(k), rs(v)                                   # (B*, h, L, d)
        assert L <= self.max_len
        pos = torch.arange(L, device=x.device)
        bias = self.rel[:, (pos[:, None] - pos[None, :]) + self.max_len - 1]   # (h, L, L)
        attn = (q @ k.transpose(-2, -1)) / math.sqrt(self.d) + bias[None]
        o = attn.softmax(-1) @ v                                        # (B*, h, L, d)
        o = o.transpose(1, 2).reshape(-1, L, C)
        if self.axis == "w":
            o = o.reshape(B, H, W, C).permute(0, 3, 1, 2)
        else:
            o = o.reshape(B, W, H, C).permute(0, 3, 2, 1)
        return self.out(o)


class TokenMHSA(nn.Module):
    """Plain multi-head self-attention on token sequences (explicit matmuls so FLOPs are counted)."""

    def __init__(self, dim, heads=8):
        super().__init__()
        self.h, self.d = heads, dim // heads
        self.qkv = nn.Linear(dim, 3 * dim, bias=False)
        self.out = nn.Linear(dim, dim, bias=False)

    def forward(self, t):
        N, L, C = t.shape
        q, k, v = self.qkv(t).reshape(N, L, 3, self.h, self.d).permute(2, 0, 3, 1, 4)
        o = ((q @ k.transpose(-2, -1)) / math.sqrt(self.d)).softmax(-1) @ v
        return self.out(o.transpose(1, 2).reshape(N, L, C))


class FullAttention2D(nn.Module):
    """Ablation: conventional global 2-D multi-head self-attention (O((HW)^2))."""

    def __init__(self, dim, heads=8):
        super().__init__()
        self.mha = TokenMHSA(dim, heads)

    def forward(self, x):
        B, C, H, W = x.shape
        o = self.mha(x.flatten(2).transpose(1, 2))
        return o.transpose(1, 2).reshape(B, C, H, W)


class WindowAttention2D(nn.Module):
    """Ablation: non-overlapping 7x7 window attention (Swin-style, without shifting)."""

    def __init__(self, dim, heads=8, win=7):
        super().__init__()
        self.win = win
        self.mha = TokenMHSA(dim, heads)

    def forward(self, x):
        B, C, H, W = x.shape
        w = self.win
        ph, pw = (w - H % w) % w, (w - W % w) % w
        xp = F.pad(x, (0, pw, 0, ph))
        Hp, Wp = xp.shape[-2:]
        t = xp.reshape(B, C, Hp // w, w, Wp // w, w).permute(0, 2, 4, 3, 5, 1).reshape(-1, w * w, C)
        o = self.mha(t)
        o = o.reshape(B, Hp // w, Wp // w, w, w, C).permute(0, 5, 1, 3, 2, 4).reshape(B, C, Hp, Wp)
        return o[..., :H, :W]


class GAAM(nn.Module):
    """Gated Axial Attention Module."""

    def __init__(self, dim, heads=8, max_len=64, attn="axial", gate=True, ffn_ratio=2):
        super().__init__()
        self.norm1 = nn.BatchNorm2d(dim)
        self.attn_type = attn
        if attn == "axial":
            self.row = AxialAttention(dim, heads, max_len, "w")
            self.col = AxialAttention(dim, heads, max_len, "h")
        elif attn == "full":
            self.mix = FullAttention2D(dim, heads)
        elif attn == "window":
            self.mix = WindowAttention2D(dim, heads)
        else:
            raise ValueError(attn)
        self.use_gate = gate
        if gate:   # depthwise 3x3 (local context) + pointwise -> sigmoid, shape C x H x W
            self.gate = nn.Sequential(nn.Conv2d(dim, dim, 3, padding=1, groups=dim, bias=False),
                                      nn.Conv2d(dim, dim, 1))
        self.proj = nn.Sequential(nn.Conv2d(dim, dim, 1, bias=False), nn.BatchNorm2d(dim))
        hid = dim * ffn_ratio
        self.ffn = nn.Sequential(nn.BatchNorm2d(dim), nn.Conv2d(dim, hid, 1), nn.GELU(),
                                 nn.Conv2d(hid, hid, 3, padding=1, groups=hid), nn.GELU(),
                                 nn.Conv2d(hid, dim, 1))
        self.ls1 = nn.Parameter(torch.zeros(1, dim, 1, 1))   # layer scale (identity at init)
        self.ls2 = nn.Parameter(torch.zeros(1, dim, 1, 1))

    def forward(self, x):
        y = self.norm1(x)
        a = self.col(self.row(y)) if self.attn_type == "axial" else self.mix(y)
        if self.use_gate:
            g = torch.sigmoid(self.gate(y))
            a = g * a + (1 - g) * y
        x = x + self.ls1 * self.proj(a)
        return x + self.ls2 * self.ffn(x)


# ----------------------------------------------------------------------------------------------
# Encoder
# ----------------------------------------------------------------------------------------------
class BasicBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(cin, cout, 3, stride, 1, bias=False); self.bn1 = nn.BatchNorm2d(cout)
        self.conv2 = nn.Conv2d(cout, cout, 3, 1, 1, bias=False); self.bn2 = nn.BatchNorm2d(cout)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = None
        if stride != 1 or cin != cout:
            self.downsample = nn.Sequential(nn.Conv2d(cin, cout, 1, stride, bias=False), nn.BatchNorm2d(cout))

    def forward(self, x):
        idt = x if self.downsample is None else self.downsample(x)
        y = self.relu(self.bn1(self.conv1(x)))
        y = self.bn2(self.conv2(y))
        return self.relu(y + idt)


def make_layer(cin, cout, n, stride):
    return nn.Sequential(BasicBlock(cin, cout, stride), *[BasicBlock(cout, cout) for _ in range(n - 1)])


class GSB(nn.Module):
    """Global Structure Branch: strided projection + two dilated depthwise-separable convs."""

    def __init__(self, cin, cout, stride, dilation):
        super().__init__()
        self.proj = conv_bn_act(cin, cout, 3, stride)
        self.dw1 = nn.Sequential(conv_bn_act(cout, cout, 3, d=dilation, groups=cout, act=False),
                                 conv_bn_act(cout, cout, 1))
        self.dw2 = nn.Sequential(conv_bn_act(cout, cout, 3, d=dilation, groups=cout, act=False),
                                 conv_bn_act(cout, cout, 1))

    def forward(self, x):
        x = self.proj(x)
        x = x + self.dw1(x)
        return x + self.dw2(x)


class DBRPEStage(nn.Module):
    def __init__(self, cin, cout, n_blocks, stride, dilation, use_ltb=True, use_gsb=True):
        super().__init__()
        assert use_ltb or use_gsb
        self.use_ltb, self.use_gsb = use_ltb, use_gsb
        if use_ltb:
            self.ltb = make_layer(cin, cout, n_blocks, stride)
        if use_gsb:
            self.gsb = GSB(cin, cout, stride, dilation)
        if use_ltb and use_gsb:
            self.fuse = conv_bn_act(2 * cout, cout, 1)

    def forward(self, x):
        if self.use_ltb and self.use_gsb:
            fl, fg = self.ltb(x), self.gsb(x)
            return fl + self.fuse(torch.cat([fl, fg], 1))
        return self.ltb(x) if self.use_ltb else self.gsb(x)


class MSFA(nn.Module):
    def __init__(self, chans, d=256, out=512, size=14, scale_attn=True):
        super().__init__()
        self.size, self.scale_attn, self.S = size, scale_attn, len(chans)
        self.proj = nn.ModuleList([conv_bn_act(c, d, 1) for c in chans])
        if scale_attn:
            self.att = nn.Sequential(nn.Linear(self.S * d, d), nn.ReLU(inplace=True), nn.Linear(d, self.S))
        self.fuse = conv_bn_act(self.S * d, out, 1)
        self.last_weights = None

    def forward(self, feats):
        ps = []
        for f, p in zip(feats, self.proj):
            f = p(f)
            if f.shape[-1] > self.size:
                f = F.adaptive_avg_pool2d(f, self.size)
            elif f.shape[-1] < self.size:
                f = F.interpolate(f, size=(self.size, self.size), mode="bilinear", align_corners=False)
            ps.append(f)
        if self.scale_attn:
            desc = torch.cat([f.mean((2, 3)) for f in ps], 1)
            w = self.att(desc).softmax(-1)                                   # (B, S)
            self.last_weights = w.detach()
            ps = [f * w[:, i, None, None, None] * self.S for i, f in enumerate(ps)]
        return self.fuse(torch.cat(ps, 1))


class MATransNet(nn.Module):
    def __init__(self, in_chans=1, num_classes=3, img_size=224, heads=8, gaam_stages=(2, 3, 4),
                 attn="axial", gate=True, use_ltb=True, use_gsb=True, use_msfa=True, scale_attn=True,
                 dilations=(4, 3, 2, 1), blocks=(3, 4, 6, 3), chans=(64, 128, 256, 512), drop=0.3):
        super().__init__()
        self.stem = nn.Sequential(nn.Conv2d(in_chans, 64, 7, 2, 3, bias=False), nn.BatchNorm2d(64),
                                  nn.ReLU(inplace=True), nn.MaxPool2d(3, 2, 1))
        cins = (64,) + tuple(chans[:-1])
        strides = (1, 2, 2, 2)
        self.stages = nn.ModuleList([DBRPEStage(ci, co, n, s, d, use_ltb, use_gsb)
                                     for ci, co, n, s, d in zip(cins, chans, blocks, strides, dilations)])
        res = [img_size // 4 // (2 ** i) for i in range(4)]
        self.gaam = nn.ModuleList([GAAM(c, heads, max_len=max(r, 8), attn=attn, gate=gate)
                                   if (i + 1) in gaam_stages else nn.Identity()
                                   for i, (c, r) in enumerate(zip(chans, res))])
        self.use_msfa = use_msfa
        if use_msfa:
            self.msfa = MSFA(chans, d=256, out=512, size=res[2], scale_attn=scale_attn)
            feat = 512
        else:
            feat = chans[-1]
        self.head = nn.Sequential(nn.Linear(feat, 256), nn.BatchNorm1d(256), nn.ReLU(inplace=True),
                                  nn.Dropout(drop), nn.Linear(256, num_classes))

    def features(self, x):
        x = self.stem(x)
        feats = []
        for st, ga in zip(self.stages, self.gaam):
            x = ga(st(x))
            feats.append(x)
        return self.msfa(feats) if self.use_msfa else feats[-1]

    def forward(self, x):
        return self.head(self.features(x).mean((2, 3)))

    def cam_layer(self):
        return self.msfa.fuse if self.use_msfa else self.gaam[-1]


def load_resnet34_into_ltb(model, in_chans=1):
    """Initialises the stem and the LTB of every stage from ImageNet ResNet-34 (timm weights)."""
    import timm
    r = timm.create_model("resnet34", pretrained=True, in_chans=in_chans)
    sd = r.state_dict()
    own = model.state_dict()
    mapped = {}
    for k, v in sd.items():
        if k.startswith("conv1."):
            mapped["stem.0." + k[6:]] = v
        elif k.startswith("bn1."):
            mapped["stem.1." + k[4:]] = v
        elif k.startswith("layer"):
            s = int(k[5]) - 1
            mapped[f"stages.{s}.ltb." + k[7:]] = v
    ok = {k: v for k, v in mapped.items() if k in own and own[k].shape == v.shape}
    model.load_state_dict(ok, strict=False)
    print(f"[model] loaded {len(ok)}/{len(mapped)} ResNet-34 tensors into stem/LTB")
    return model


# ----------------------------------------------------------------------------------------------
# Factory (proposed model, ablations and baselines)
# ----------------------------------------------------------------------------------------------
ABLATIONS = {
    "full": {},
    "no_gaam": dict(gaam_stages=()),
    "no_gate": dict(gate=False),
    "attn_full": dict(attn="full"),
    "attn_window": dict(attn="window"),
    "no_gsb": dict(use_gsb=False),
    "no_ltb": dict(use_ltb=False),
    "no_msfa": dict(use_msfa=False),
    "msfa_concat": dict(scale_attn=False),
}

BASELINES = {
    "resnet50": "resnet50",
    "densenet121": "densenet121",
    "efficientnet_b0": "efficientnet_b0",
    "mobilenetv3": "mobilenetv3_large_100",
    "convnext_tiny": "convnext_tiny",
    "vit_small": "vit_small_patch16_224",
    "deit_small": "deit_small_patch16_224",
    "swin_tiny": "swin_tiny_patch4_window7_224",
    "maxvit_tiny": "maxvit_tiny_tf_224",
    "resnet18": "resnet18",
    "convnext_atto": "convnext_atto",
    "deit_tiny": "deit_tiny_patch16_224",
}


SMALL = dict(heads=4, chans=(32, 64, 128, 256), blocks=(2, 2, 2, 2))


def build_model(name, num_classes=3, in_chans=1, img_size=224, pretrained=True, variant="full", size="base"):
    if name == "matransnet":
        kw = dict(ABLATIONS[variant])
        if size == "small":
            kw.update(SMALL)
        m = MATransNet(in_chans, num_classes, img_size, **kw)
        if size == "small":
            return m                       # compact variant has no ResNet-34 counterpart
        if pretrained and ABLATIONS[variant].get("use_ltb", True):
            try:
                load_resnet34_into_ltb(m, in_chans)
            except Exception as e:   # offline -> train from scratch, but say so loudly
                print(f"[model] WARNING: could not load ResNet-34 weights ({e}); training from scratch")
        return m
    import timm
    kw = {"img_size": img_size} if name in ("deit_tiny", "vit_small", "deit_small") else {}
    return timm.create_model(BASELINES[name], pretrained=pretrained, num_classes=num_classes,
                             in_chans=in_chans, **kw)
