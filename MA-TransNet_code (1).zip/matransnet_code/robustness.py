"""Robustness of trained models to acquisition-like perturbations (test folds, seed-0 checkpoints).

Perturbations are applied to the [0,1]-scaled image before resizing / z-scoring:
  Rician noise at SNR = 30, 20, 10 dB (SNR = mean foreground intensity / sigma, in dB),
  Gaussian blur (sigma = 1, 2 px), multiplicative smooth bias field (amplitude 0.3),
  gamma 0.7 / 1.5, and 2x down/up-sampling (resolution loss).
Usage: python robustness.py --runs runs --data_dir ./figshare --out results
"""
import argparse
import json
import os

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, f1_score

from data import load_cache, load_folds, split_indices
from model import build_model

MODELS = {"MATRANSNET": ("matransnet", "matransnet_full_dwfl_c0.5"),
          "CONVNEXT": ("convnext_tiny", "convnext_tiny_full_ce_c0"),
          "SWINT": ("swin_tiny", "swin_tiny_full_ce_c0")}


def rician(x, snr_db, rng):
    fg = x[x > 0.05]
    sigma = (fg.mean() if fg.size else x.mean()) / (10 ** (snr_db / 20))
    return np.sqrt((x + rng.normal(0, sigma, x.shape)) ** 2 + rng.normal(0, sigma, x.shape) ** 2)


def bias_field(x, amp, rng):
    h, w = x.shape
    yy, xx = np.meshgrid(np.linspace(-1, 1, h), np.linspace(-1, 1, w), indexing="ij")
    c = rng.normal(0, 1, 6)
    f = c[0] * xx + c[1] * yy + c[2] * xx * yy + c[3] * xx ** 2 + c[4] * yy ** 2 + c[5]
    f = (f - f.mean()) / (f.std() + 1e-8)
    return x * np.exp(amp * f / 2)


CONDITIONS = {
    "CLEAN": lambda x, r: x,
    "RICIAN30": lambda x, r: rician(x, 30, r), "RICIAN20": lambda x, r: rician(x, 20, r),
    "RICIAN10": lambda x, r: rician(x, 10, r),
    "BLUR1": lambda x, r: cv2.GaussianBlur(x, (0, 0), 1.0), "BLUR2": lambda x, r: cv2.GaussianBlur(x, (0, 0), 2.0),
    "BIAS": lambda x, r: bias_field(x, 0.3, r),
    "GAMMA07": lambda x, r: np.clip(x, 0, None) ** 0.7, "GAMMA15": lambda x, r: np.clip(x, 0, None) ** 1.5,
    "LOWRES": lambda x, r: cv2.resize(cv2.resize(x, (128, 128), interpolation=cv2.INTER_AREA), (256, 256)),
}


@torch.no_grad()
def evaluate(model, data, idx, cond, mean, std, dev, bs=64):
    rng = np.random.default_rng(0)
    P = []
    for s in range(0, len(idx), bs):
        xs = []
        for j in idx[s:s + bs]:
            x = CONDITIONS[cond](data["imgs"][j].astype(np.float32), rng).astype(np.float32)
            xs.append(cv2.resize(x, (224, 224), interpolation=cv2.INTER_LINEAR))
        x = (torch.from_numpy(np.stack(xs))[:, None] - mean) / std
        P.append(F.softmax(model(x.to(dev)), -1).cpu().numpy())
    return np.concatenate(P)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs"); ap.add_argument("--data_dir", required=True)
    ap.add_argument("--out", default="results"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--limit", type=int, default=0, help="debug: samples per fold")
    a = ap.parse_args()
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data = load_cache(a.data_dir)
    folds = load_folds(a.data_dir, data["labels"], data["pids"], data["idx"])
    R = {}
    for key, (name, group) in MODELS.items():
        res = {c: ([], []) for c in CONDITIONS}
        for k in range(5):
            run = os.path.join(a.runs, f"{group}_f{k}_s{a.seed}")
            if not os.path.exists(os.path.join(run, "best.pt")):
                continue
            cfg = json.load(open(os.path.join(run, "config.json")))
            m = build_model(name, pretrained=False, variant=cfg.get("variant", "full")).to(dev).eval()
            m.load_state_dict(torch.load(os.path.join(run, "best.pt"), map_location=dev))
            _, _, te = split_indices(folds, k)
            if a.limit:
                te = te[:a.limit]
            for c in CONDITIONS:
                p = evaluate(m, data, te, c, cfg["norm_mean"], cfg["norm_std"], dev)
                res[c][0].append(p); res[c][1].append(data["labels"][te])
        for c, (P, Y) in res.items():
            if P:
                p, y = np.concatenate(P), np.concatenate(Y)
                R[f"ROB_{c}_{key}_ACC"] = f"{100 * accuracy_score(y, p.argmax(1)):.2f}"
                R[f"ROB_{c}_{key}_F1"] = f"{100 * f1_score(y, p.argmax(1), average='macro'):.2f}"
        print(key, {c: R.get(f"ROB_{c}_{key}_ACC") for c in CONDITIONS})
    path = os.path.join(a.out, "results.json")
    os.makedirs(a.out, exist_ok=True)
    old = json.load(open(path)) if os.path.exists(path) else {}
    old.update(R); json.dump(old, open(path, "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
