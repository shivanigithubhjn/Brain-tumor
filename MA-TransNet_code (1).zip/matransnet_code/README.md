# MA-TransNet: code for the manuscript

This code trains and evaluates every model in the manuscript and fills its ⟦…⟧ placeholders with the measured results.

## 1. Data
Download all five files from https://figshare.com/articles/dataset/brain_tumor_dataset/1512427:
`brainTumorDataPublic_1-766.zip`, `_767-1532.zip`, `_1533-2298.zip`, `_2299-3064.zip` and **`cvind.mat`**.
Unzip the four archives into **one** folder (for example `./figshare`) together with `cvind.mat`.
You should end up with `1.mat … 3064.mat` and `cvind.mat` in that folder.

`cvind.mat` is the official patient-wise 5-fold split. Without it the code falls back to its own
patient-wise split, but the paper describes the official one, so use it.

## 2. Environment (Google Colab GPU or any CUDA machine)
```bash
pip install -r requirements.txt
```
The first run downloads ImageNet weights from the Hugging Face hub (internet required).

## 3. Quick check (about 2 minutes)
```bash
python train.py --data_dir ./figshare --model matransnet --fold 0 --epochs 1 --max_steps 5 --out runs_debug
```

## 4. Full protocol
```bash
DATA=./figshare bash run_all.sh
```
This runs, in order:
1. The main comparison: MA-TransNet and 9 baselines × 5 folds × 3 seeds = 150 runs.
2. The ablations: 15 variants × 5 folds × 1 seed = 75 runs.
3. The analysis scripts: `evaluate.py`, `xai.py`, `robustness.py` and `efficiency.py`, which write `results/results.json` and `results/figs/*.png`.
4. `fill_results.py`, which writes `MA-TransNet_manuscript_filled.docx`.

Rough cost on one T4 GPU: about 40–45 GPU-hours in total. To cut it, use `SEEDS="0"` (about 15 GPU-hours) and note in the paper that a single seed was used. You can also run folds in parallel on several sessions; every run writes to its own folder under `runs/`.

On Colab, keep `runs/` on Google Drive so that runs survive disconnects. `run_all.sh` can be restarted: comment out the runs that are already finished.

## 5. Filling the manuscript
```bash
python fill_results.py --docx MA-TransNet_manuscript.docx --results results/results.json --out MA-TransNet_manuscript_filled.docx
```
The script reports placeholders that are still unfilled, so nothing is invented.
After filling:
- Read every sentence marked «AUTHOR …» (red text) and rewrite it to match your actual numbers, then delete the marker.
- If a component does **not** help in the ablation, say so honestly in the paper.
- Fill in the authors, affiliations, CRediT statement, funding and the GitHub/Zenodo link.

## Files
| File | Purpose |
|---|---|
| `data.py` | Reads the .mat files, preprocesses (percentile clip, CLAHE), caches, builds patient-wise folds, augmentation, CutMix |
| `model.py` | MA-TransNet (DBRPE, GAAM, MSFA, DCH), ablation variants and timm baselines |
| `losses.py` | DWFL, consistency loss, CE/weighted CE/focal/class-balanced focal |
| `train.py` | One run (model × variant × loss × fold × seed) |
| `evaluate.py` | Metrics, mean ± SD, patient-cluster bootstrap CIs, McNemar/Wilcoxon with Holm correction, confusion matrix, ROC and training-curve figures |
| `xai.py` | Grad-CAM and its agreement with expert masks (IoU, pointing game, energy pointing game) |
| `robustness.py` | Rician noise, blur, bias field, gamma and low-resolution tests |
| `efficiency.py` | Params, FLOPs, latency and training memory |
| `fill_results.py` | Puts results and figures into the .docx |

---
## 15-class collection (experiments reported in MA-TransNet_15class_manuscript_FINAL.docx)
* `data_folder.py` – perceptual-hash duplicate audit, label-conflict removal, duplicate groups, group-stratified 70/10/20 split.
* `split_15class.csv` – the exact split used in the paper (file, class, duplicate group, subset, original folder).
* `run_job.sh "<args>"` – one training run with the paper's CPU protocol (128 px, from scratch, 25 epochs).
  Final model: `--model matransnet --size small --loss ce`  (consistency λ=0.5 is the default for MA-TransNet).
  Leaky-split comparison: add `--orig_split`.
* `evaluate_folder.py --runs RUNS --cache CACHE --out OUT --audit audit.npz --robust --xai --eff` – all metrics, statistics, figures.
* `results_15class/` – results.json, figures, and per-image test predictions + training histories of every run.
* Group-wise 5-fold cross-validation: add `--cv_fold k` (k = 0..4); summarise with `python cv_eval.py RUNS CACHE results.json`.
