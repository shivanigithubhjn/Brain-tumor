"""Train one (model, variant, loss, fold, seed) configuration with patient-wise splits.

Example:
  python train.py --data_dir ./figshare --model matransnet --fold 0 --seed 0
  python train.py --data_dir ./figshare --model convnext_tiny --loss ce --fold 0 --seed 0
  python train.py --data_dir ./figshare --model matransnet --variant no_gaam --fold 0 --seed 0
Outputs (in --out/<tag>/): best.pt, history.json, pred_test.npz (probs, labels, sample indices),
pred_val.npz, config.json.
"""
import argparse
import json
import os
import random
import time

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader

from data import (FigshareDataset, cutmix, load_cache, load_folds, split_indices, train_stats)
from data_folder import load_folder
from losses import build_loss, consistency_loss, consistency_weight
from model import build_model

DEFAULT_LR = {"matransnet": 3e-4, "resnet50": 3e-4, "densenet121": 3e-4, "efficientnet_b0": 3e-4,
              "mobilenetv3": 3e-4, "convnext_tiny": 1e-4, "vit_small": 1e-4, "deit_small": 1e-4,
              "swin_tiny": 1e-4, "maxvit_tiny": 1e-4}


def get_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", required=True)
    p.add_argument("--out", default="runs")
    p.add_argument("--model", default="matransnet")
    p.add_argument("--variant", default="full")
    p.add_argument("--loss", default=None, help="default: dwfl for matransnet, ce for baselines")
    p.add_argument("--cons", type=float, default=None, help="lambda_cons (default 0.5 for matransnet, 0 otherwise)")
    p.add_argument("--sigma", type=float, default=0.1, help="std of the consistency perturbation")
    p.add_argument("--fold", type=int, default=0)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--epochs", type=int, default=60)
    p.add_argument("--warmup", type=int, default=3)
    p.add_argument("--patience", type=int, default=12)
    p.add_argument("--bs", type=int, default=32)
    p.add_argument("--lr", type=float, default=None)
    p.add_argument("--wd", type=float, default=0.05)
    p.add_argument("--img", type=int, default=224)
    p.add_argument("--p_cutmix", type=float, default=0.3)
    p.add_argument("--gamma", type=float, default=2.0)
    p.add_argument("--rho", type=float, default=0.9)
    p.add_argument("--no_pretrained", action="store_true")
    p.add_argument("--no_clahe", action="store_true")
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--max_steps", type=int, default=0, help="debug: limit steps per epoch")
    p.add_argument("--dataset", default="figshare", choices=["figshare", "folder"])
    p.add_argument("--cache_dir", default=None, help="folder dataset: where to store the cache")
    p.add_argument("--size", default="base", choices=["base", "small"], help="MA-TransNet width")
    p.add_argument("--threads", type=int, default=0)
    p.add_argument("--orig_split", action="store_true", help="folder dataset: use the provided (leaky) train/test folders")
    p.add_argument("--cv_fold", type=int, default=-1, help="folder dataset: group-wise 5-fold CV, test fold k (0-4)")
    return p.parse_args()


def seed_all(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)


@torch.no_grad()
def predict(model, loader, device, max_steps=0):
    model.eval()
    P, Y, I = [], [], []
    for step, (x, y, _, idx) in enumerate(loader):
        if max_steps and step >= max_steps:
            break
        with torch.autocast(device.type, enabled=device.type == "cuda"):
            P.append(F.softmax(model(x.to(device).contiguous(memory_format=torch.channels_last)).float(), -1).cpu())
        Y.append(y); I.append(idx)
    return torch.cat(P).numpy(), torch.cat(Y).numpy(), torch.cat(I).numpy()


def macro_auc(p, y, K=3):
    try:
        return roc_auc_score(y, p, multi_class="ovr", average="macro", labels=list(range(K)))
    except ValueError:
        return float("nan")


def main():
    a = get_args()
    seed_all(a.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    loss_name = a.loss or ("dwfl" if a.model == "matransnet" else "ce")
    lam = a.cons if a.cons is not None else (0.5 if a.model == "matransnet" else 0.0)
    lr = a.lr or DEFAULT_LR.get(a.model, 3e-4)
    tag = f"{a.model}_{a.variant}_{loss_name}_c{lam:g}_f{a.fold}_s{a.seed}"
    if a.dataset == "folder":
        tag = f"{a.model}{'-S' if a.size == 'small' and a.model == 'matransnet' else ''}_{a.variant}_{loss_name}_c{lam:g}{'_origsplit' if a.orig_split else ''}{f'_cv{a.cv_fold}' if a.cv_fold >= 0 else ''}_s{a.seed}"
    out = os.path.join(a.out, tag)
    os.makedirs(out, exist_ok=True)

    if a.threads:
        torch.set_num_threads(a.threads)
    if a.dataset == "folder":
        data = load_folder(a.data_dir, a.cache_dir or os.path.join(a.out, "_cache"))
        tr, va, te = [np.where(data["subset"] == s)[0] for s in ("train", "val", "test")]
        if a.cv_fold >= 0:                     # group-stratified 5-fold CV over all duplicate groups
            from sklearn.model_selection import StratifiedGroupKFold
            lab, grp = data["labels"], data["groups"]
            outer = list(StratifiedGroupKFold(5, shuffle=True, random_state=0).split(np.zeros(len(lab)), lab, grp))
            rest, te = outer[a.cv_fold]
            inner = next(StratifiedGroupKFold(8, shuffle=True, random_state=0).split(np.zeros(len(rest)), lab[rest], grp[rest]))
            tr, va = rest[inner[0]], rest[inner[1]]
        if a.orig_split:                       # provided folders; 10% of the training groups -> validation
            te = np.where(data["orig_split"] == "test")[0]
            trall = np.where(data["orig_split"] == "train")[0]
            ug = np.unique(data["groups"][trall]); rng = np.random.default_rng(0)
            vg = set(rng.choice(ug, int(0.1 * len(ug)), replace=False))
            va = np.array([i for i in trall if data["groups"][i] in vg]); tr = np.array([i for i in trall if data["groups"][i] not in vg])
    else:
        data = load_cache(a.data_dir, 256, clahe=not a.no_clahe)
        folds = load_folds(a.data_dir, data["labels"], data["pids"], data["idx"])
        tr, va, te = split_indices(folds, a.fold)
    K = int(data["labels"].max()) + 1
    assert a.orig_split or not (set(data["pids"][tr]) & set(data["pids"][te])), "patient leakage train/test"
    assert not (set(data["pids"][tr]) & set(data["pids"][va])), "patient leakage train/val"
    mean, std = train_stats(data, tr)
    counts = np.bincount(data["labels"][tr], minlength=K)
    print(f"[{tag}] train {len(tr)} ({len(set(data['pids'][tr]))} pts) | val {len(va)} | test {len(te)} | counts {counts}")

    mk = lambda idx, train: FigshareDataset(data, idx, a.img, train, mean, std)
    dl_tr = DataLoader(mk(tr, True), a.bs, shuffle=True, num_workers=a.workers, drop_last=True,
                       pin_memory=device.type == "cuda", persistent_workers=a.workers > 0)
    dl_va = DataLoader(mk(va, False), a.bs * 2, num_workers=a.workers)
    dl_te = DataLoader(mk(te, False), a.bs * 2, num_workers=a.workers)

    model = build_model(a.model, K, 1, a.img, pretrained=not a.no_pretrained, variant=a.variant, size=a.size).to(device)
    model = model.to(memory_format=torch.channels_last)
    crit = build_loss(loss_name, counts.tolist(), a.gamma, a.rho).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=a.wd)
    steps = len(dl_tr) if not a.max_steps else min(a.max_steps, len(dl_tr))
    total, warm = a.epochs * steps, a.warmup * steps
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: (s + 1) / max(warm, 1) if s < warm else 0.5 * (1 + np.cos(np.pi * (s - warm) / max(total - warm, 1))))
    scaler = torch.amp.GradScaler(enabled=device.type == "cuda")

    json.dump({**vars(a), "loss": loss_name, "cons": lam, "lr": lr, "tag": tag,
               "n_train": len(tr), "n_val": len(va), "n_test": len(te), "train_counts": counts.tolist(),
               "norm_mean": mean, "norm_std": std, "num_classes": K}, open(os.path.join(out, "config.json"), "w"), indent=1)

    best, best_ep, hist, wait, start = -1.0, -1, [], 0, 0
    last = os.path.join(out, "last.pt")
    if os.path.exists(os.path.join(out, "pred_test.npz")):
        print(f"[{tag}] already finished"); return
    if os.path.exists(last):                                  # resume an interrupted run
        ck = torch.load(last, map_location=device, weights_only=False)
        model.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"]); sched.load_state_dict(ck["sched"])
        crit.load_state_dict(ck["crit"]); best, best_ep, hist, wait, start = ck["best"], ck["best_ep"], ck["hist"], ck["wait"], ck["epoch"] + 1
        np.random.set_state(ck["np_rng"]); torch.set_rng_state(ck["torch_rng"])
        print(f"[{tag}] resumed at epoch {start}")
    for ep in range(start, a.epochs):
        if wait >= a.patience:
            break
        model.train(); crit.train()
        t0, run = time.time(), {"loss": 0.0, "cons": 0.0, "n": 0}
        w_c = consistency_weight(ep, lam) if lam > 0 else 0.0
        for step, (x, y, _, _) in enumerate(dl_tr):
            if a.max_steps and step >= a.max_steps:
                break
            x, y = x.to(device, non_blocking=True).contiguous(memory_format=torch.channels_last), y.to(device, non_blocking=True)
            tgt = F.one_hot(y, K).float()
            if a.p_cutmix > 0 and np.random.rand() < a.p_cutmix:
                x, tgt = cutmix(x, tgt)
            with torch.autocast(device.type, enabled=device.type == "cuda"):
                if w_c > 0:
                    xp = x + torch.randn_like(x) * a.sigma
                    logits = model(torch.cat([x, xp]))
                    lc, lp = logits.chunk(2)
                    l_sup = crit(lc, tgt)
                    l_con = consistency_loss(lc, lp)
                    loss = l_sup + w_c * l_con
                else:
                    lc = model(x)
                    l_sup = crit(lc, tgt); l_con = torch.zeros((), device=device)
                    loss = l_sup
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(opt); scaler.update(); sched.step()
            run["loss"] += l_sup.item() * len(y); run["cons"] += l_con.item() * len(y); run["n"] += len(y)
        crit.epoch_end()
        pv, yv, _ = predict(model, dl_va, device, a.max_steps)
        auc = macro_auc(pv, yv, K)
        acc = float((pv.argmax(1) == yv).mean())
        val_loss = float(F.nll_loss(torch.log(torch.from_numpy(pv) + 1e-8), torch.from_numpy(yv)).item())
        rec = {"epoch": ep, "train_loss": run["loss"] / max(run["n"], 1), "train_cons": run["cons"] / max(run["n"], 1),
               "val_auc": auc, "val_acc": acc, "val_loss": val_loss, "lr": opt.param_groups[0]["lr"],
               "time_s": time.time() - t0}
        if hasattr(crit, "weights"):
            rec["dwfl_beta"] = crit.weights().cpu().tolist()
        hist.append(rec)
        print(f"[{tag}] ep {ep:03d} loss {rec['train_loss']:.4f} val_auc {auc:.4f} val_acc {acc:.4f} ({rec['time_s']:.0f}s)")
        score = auc if not np.isnan(auc) else acc
        if score > best + 1e-5:
            best, best_ep, wait = score, ep, 0
            torch.save(model.state_dict(), os.path.join(out, "best.pt"))
        else:
            wait += 1
        torch.save({"model": model.state_dict(), "opt": opt.state_dict(), "sched": sched.state_dict(),
                    "crit": crit.state_dict(), "best": best, "best_ep": best_ep, "hist": hist, "wait": wait,
                    "epoch": ep, "np_rng": np.random.get_state(), "torch_rng": torch.get_rng_state()}, last)
        if wait >= a.patience:
            print(f"[{tag}] early stopping at epoch {ep} (best {best_ep})")
            break
    json.dump(hist, open(os.path.join(out, "history.json"), "w"), indent=1)

    model.load_state_dict(torch.load(os.path.join(out, "best.pt"), map_location=device))
    accs = {}
    for name, dl in (("test", dl_te), ("val", dl_va)):
        p, y, idx = predict(model, dl, device, a.max_steps)
        np.savez(os.path.join(out, f"pred_{name}.npz"), probs=p, labels=y, idx=idx,
                 pids=data["pids"][idx])
        accs[name] = float((p.argmax(1) == y).mean())
    print(f"[{tag}] done. best val epoch {best_ep}; val acc {accs['val']:.4f}; test acc {accs['test']:.4f}")
    if os.path.exists(last):
        os.remove(last)


if __name__ == "__main__":
    main()
