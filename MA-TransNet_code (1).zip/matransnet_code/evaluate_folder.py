"""Analysis of the compact protocol on the 15-class folder dataset (single group-stratified test set).

Outputs results_folder/results.json (flat key -> string) and figures in results_folder/figs.
Usage: python evaluate_folder.py --runs RUNS --cache CACHE_DIR --out results_folder [--robust] [--xai] [--eff]
"""
import argparse
import glob
import json
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.stats import binomtest
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, cohen_kappa_score, confusion_matrix,
                             f1_score, matthews_corrcoef, precision_score, recall_score, roc_auc_score, roc_curve)

PRETTY = {"matransnet-S": "MA-TransNet-S", "resnet18": "ResNet-18", "convnext_atto": "ConvNeXt-Atto",
          "deit_tiny": "DeiT-Tiny", "mobilenetv3": "MobileNetV3-L", "efficientnet_b0": "EfficientNet-B0"}
MAIN = "matransnet-S_full_ce_c0.5"          # validation-selected configuration (CE + consistency)
BASE = {k: f"{k}_full_ce_c0" for k in ("resnet18", "convnext_atto", "deit_tiny", "mobilenetv3", "efficientnet_b0")}
ABL = {"FULL": MAIN, "NO_GAAM": "matransnet-S_no_gaam_ce_c0.5", "NO_GATE": "matransnet-S_no_gate_ce_c0.5",
       "ATTN_FULL": "matransnet-S_attn_full_ce_c0.5", "NO_GSB": "matransnet-S_no_gsb_ce_c0.5",
       "NO_MSFA": "matransnet-S_no_msfa_ce_c0.5", "NO_CONS": "matransnet-S_full_ce_c0",
       "LOSS_DWFL": "matransnet-S_full_dwfl_c0.5", "LOSS_CBFOCAL": "matransnet-S_full_cbfocal_c0.5",
       "DWFL_NO_GAAM": "matransnet-S_no_gaam_dwfl_c0.5"}
LEAK = "matransnet-S_full_ce_c0.5_origsplit"


def spec_per_class(y, yp, K):
    cm = confusion_matrix(y, yp, labels=range(K)); out = []
    for k in range(K):
        tn = cm.sum() - cm[k].sum() - cm[:, k].sum() + cm[k, k]; fp = cm[:, k].sum() - cm[k, k]
        out.append(tn / max(tn + fp, 1))
    return np.array(out)


def metrics(p, y, K):
    yp = p.argmax(1)
    return {"ACC": accuracy_score(y, yp), "BACC": balanced_accuracy_score(y, yp),
            "PREC": precision_score(y, yp, average="macro", zero_division=0),
            "REC": recall_score(y, yp, average="macro", zero_division=0),
            "SPEC": spec_per_class(y, yp, K).mean(), "F1": f1_score(y, yp, average="macro", zero_division=0),
            "AUC": roc_auc_score(y, p, multi_class="ovr", average="macro", labels=list(range(K))),
            "MCC": matthews_corrcoef(y, yp), "KAPPA": cohen_kappa_score(y, yp)}


def pct(v): return f"{100 * v:.2f}"
def dec(v): return f"{v:.4f}"
def fm(m, v): return dec(v) if m in ("AUC", "MCC", "KAPPA") else pct(v)


def boot_ci(p, y, groups, fn, n=2000, seed=0):
    rng = np.random.default_rng(seed); ug = np.unique(groups); rows = {g: np.where(groups == g)[0] for g in ug}
    st = []
    for _ in range(n):
        sel = np.concatenate([rows[g] for g in rng.choice(ug, len(ug), replace=True)])
        if len(np.unique(y[sel])) < p.shape[1]:          # every class must be present (needed for macro-AUC)
            continue
        try:
            v = fn(p[sel], y[sel])
        except ValueError:
            continue
        if not np.isnan(v):
            st.append(v)
    return np.percentile(st, [2.5, 97.5])


def paired_boot_diff(pa, pb, y, groups, n=2000, seed=0):
    rng = np.random.default_rng(seed); ug = np.unique(groups); rows = {g: np.where(groups == g)[0] for g in ug}
    ca, cb = (pa.argmax(1) == y), (pb.argmax(1) == y); d = []
    for _ in range(n):
        sel = np.concatenate([rows[g] for g in rng.choice(ug, len(ug), replace=True)])
        d.append(ca[sel].mean() - cb[sel].mean())
    return np.percentile(d, [2.5, 97.5])


def mcnemar(y, a, b):
    ca, cb = a == y, b == y; n01, n10 = int((ca & ~cb).sum()), int((~ca & cb).sum())
    return (binomtest(n01, n01 + n10, 0.5).pvalue if n01 + n10 else 1.0), n01, n10


def holm(d):
    ks = sorted(d, key=d.get); m = len(ks); out, prev = {}, 0
    for i, k in enumerate(ks):
        prev = max(prev, min(1, (m - i) * d[k])); out[k] = prev
    return out


def fp(p): return "< 0.001" if p < 0.001 else f"{p:.3f}"


def load(runs, group, seed=0):
    f = os.path.join(runs, f"{group}_s{seed}", "pred_test.npz")
    if not os.path.exists(f):
        return None
    d = np.load(f, allow_pickle=True)
    return d["probs"], d["labels"], d["idx"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True); ap.add_argument("--cache", required=True)
    ap.add_argument("--out", default="results_folder")
    ap.add_argument("--robust", action="store_true"); ap.add_argument("--xai", action="store_true")
    ap.add_argument("--eff", action="store_true")
    ap.add_argument("--audit", default=None, help="audit.npz with pairwise pHash distances")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "figs"), exist_ok=True)
    data = np.load(glob.glob(os.path.join(a.cache, "folder_cache_*.npz"))[0], allow_pickle=False)
    classes = [str(c) for c in data["classes"]]; K = len(classes); groups_all = data["groups"]
    R = {"N_CLASSES": str(K), "N_IMAGES": str(len(data["labels"])), "N_DROPPED": str(int(data["n_dropped"])),
         "N_GROUPS": str(len(np.unique(groups_all)))}
    for s in ("train", "val", "test"):
        m = data["subset"] == s
        R[f"N_{s.upper()}"] = str(int(m.sum())); R[f"N_{s.upper()}_GROUPS"] = str(len(np.unique(groups_all[m])))
        for k, c in enumerate(classes):
            R[f"DS_{k}_{s.upper()}"] = str(int((data["labels"][m] == k).sum()))
    for k, c in enumerate(classes):
        R[f"DS_{k}_NAME"] = c; R[f"DS_{k}_TOTAL"] = str(int((data["labels"] == k).sum()))
        R[f"DS_{k}_GROUPS"] = str(len(np.unique(groups_all[data["labels"] == k])))
    os_ = data["orig_split"]
    R["ORIG_TRAIN"], R["ORIG_TEST"] = str(int((os_ == "train").sum())), str(int((os_ == "test").sum()))

    main_run = load(a.runs, MAIN)
    allp = {}
    if main_run is not None:
        p, y, idx = main_run; g = groups_all[idx]; allp["matransnet-S"] = p
        M = metrics(p, y, K)
        for m, v in M.items():
            R[f"MAIN_{m}"] = fm(m, v)
        for m, fn in (("ACC", lambda P, Y: accuracy_score(Y, P.argmax(1))),
                      ("F1", lambda P, Y: f1_score(Y, P.argmax(1), average="macro")),
                      ("BACC", lambda P, Y: balanced_accuracy_score(Y, P.argmax(1))),
                      ("AUC", lambda P, Y: roc_auc_score(Y, P, multi_class="ovr", labels=list(range(K))))):
            lo, hi = boot_ci(p, y, g, fn)
            R[f"MAIN_{m}_CI"] = f"{fm(m, lo)}–{fm(m, hi)}"
        # seeds
        seeds = [load(a.runs, MAIN, s) for s in (0, 1, 2)]
        seeds = [s for s in seeds if s is not None]
        R["N_SEEDS_MAIN"] = str(len(seeds))
        if len(seeds) > 1:
            for m in ("ACC", "F1", "BACC", "AUC", "MCC"):
                v = np.array([metrics(s[0], s[1], K)[m] for s in seeds])
                R[f"SEED_{m}"] = f"{fm(m, v.mean())} ± {fm(m, v.std(ddof=1))}"
        # per class
        yp = p.argmax(1)
        pr = precision_score(y, yp, average=None, labels=range(K), zero_division=0)
        rc = recall_score(y, yp, average=None, labels=range(K), zero_division=0)
        f1 = f1_score(y, yp, average=None, labels=range(K), zero_division=0); sp = spec_per_class(y, yp, K)
        for k in range(K):
            R[f"PC_{k}_PREC"], R[f"PC_{k}_REC"], R[f"PC_{k}_SPEC"], R[f"PC_{k}_F1"] = pct(pr[k]), pct(rc[k]), pct(sp[k]), pct(f1[k])
            R[f"PC_{k}_AUC"] = dec(roc_auc_score((y == k).astype(int), p[:, k])); R[f"PC_{k}_N"] = str(int((y == k).sum()))
        cm = confusion_matrix(y, yp, labels=range(K)); cmn = cm / cm.sum(1, keepdims=True)
        fig, ax = plt.subplots(figsize=(9.5, 8.2))
        im = ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
        for i in range(K):
            for j in range(K):
                if cm[i, j]:
                    ax.text(j, i, f"{cm[i, j]}", ha="center", va="center", fontsize=7,
                            color="white" if cmn[i, j] > 0.5 else "black")
        ax.set_xticks(range(K), classes, rotation=60, ha="right", fontsize=8); ax.set_yticks(range(K), classes, fontsize=8)
        ax.set_xlabel("Predicted class"); ax.set_ylabel("True class"); plt.colorbar(im, fraction=0.046, label="Row-normalised rate")
        plt.tight_layout(); plt.savefig(os.path.join(a.out, "figs", "confusion_matrix.png"), dpi=300); plt.close()
        # largest confusions
        off = [(cm[i, j], classes[i], classes[j]) for i in range(K) for j in range(K) if i != j]
        off.sort(reverse=True)
        R["TOP_CONFUSIONS"] = "; ".join(f"{a_} → {b_} ({n})" for n, a_, b_ in off[:4])
        order = np.argsort(f1)
        R["WORST_CLASSES"] = ", ".join(f"{classes[k]} (F1 {pct(f1[k])}%)" for k in order[:3])
        R["BEST_CLASSES"] = ", ".join(f"{classes[k]} (F1 {pct(f1[k])}%)" for k in order[::-1][:3])

    # baselines
    raw_p = {}
    for b, grp in BASE.items():
        r = load(a.runs, grp)
        if r is None:
            continue
        pb, yb, idxb = r; allp[b] = pb
        Mb = metrics(pb, yb, K)
        for m, v in Mb.items():
            R[f"CMP_{b.upper()}_{m}"] = fm(m, v)
        if main_run is not None:
            assert np.array_equal(idxb, main_run[2])
            pv, n01, n10 = mcnemar(main_run[1], main_run[0].argmax(1), pb.argmax(1)); raw_p[b] = pv
            lo, hi = paired_boot_diff(main_run[0], pb, main_run[1], groups_all[main_run[2]])
            R[f"STAT_{b.upper()}_DACC"] = f"{100 * (metrics(main_run[0], main_run[1], K)['ACC'] - Mb['ACC']):+.2f}"
            R[f"STAT_{b.upper()}_DCI"] = f"{100 * lo:+.2f} to {100 * hi:+.2f}"
            R[f"STAT_{b.upper()}_N01"], R[f"STAT_{b.upper()}_N10"] = str(n01), str(n10)
    for b, pv in holm(raw_p).items():
        R[f"STAT_{b.upper()}_MCN_P"] = fp(pv)
    if main_run is not None:
        for m, v in metrics(main_run[0], main_run[1], K).items():
            R[f"CMP_MATRANSNET-S_{m}"] = fm(m, v)
    if raw_p:
        accs = {b: metrics(allp[b], main_run[1], K)["ACC"] for b in raw_p}
        kb = max(accs, key=accs.get); R["BEST_BASELINE"] = PRETTY[kb]; R["BEST_BASELINE_KEY"] = kb
        R["BEST_BASELINE_ACC"] = pct(accs[kb]); R["BEST_DACC"] = R[f"STAT_{kb.upper()}_DACC"]
        R["BEST_DCI"] = R[f"STAT_{kb.upper()}_DCI"]; R["BEST_MCN_P"] = R[f"STAT_{kb.upper()}_MCN_P"]
        R["BEST_BASELINE_F1"] = pct(metrics(allp[kb], main_run[1], K)["F1"])
        seeds_b = [load(a.runs, BASE[kb], s) for s in (0, 1, 2)]; seeds_b = [s for s in seeds_b if s is not None]
        if len(seeds_b) > 1:
            for m in ("ACC", "F1", "BACC", "AUC", "MCC"):
                v = np.array([metrics(s[0], s[1], K)[m] for s in seeds_b]); R[f"SEEDB_{m}"] = f"{fm(m, v.mean())} ± {fm(m, v.std(ddof=1))}"

    # ROC (macro) for all models
    if allp:
        y = main_run[1]; grid = np.linspace(0, 1, 300)
        fig, ax = plt.subplots(figsize=(5.6, 4.6))
        for k_, pp in allp.items():
            t = []
            for c in range(K):
                fpr, tpr, _ = roc_curve((y == c).astype(int), pp[:, c]); t.append(np.interp(grid, fpr, tpr))
            ax.plot(grid, np.mean(t, 0), lw=2.4 if k_ == "matransnet-S" else 1.2,
                    label=f"{PRETTY[k_]} (AUC {roc_auc_score(y, pp, multi_class='ovr', labels=list(range(K))):.4f})")
        ax.plot([0, 1], [0, 1], "k--", lw=0.8); ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
        ax.set_title("Macro-averaged one-vs-rest ROC (test set)"); ax.legend(fontsize=7.5, loc="lower right")
        plt.tight_layout(); plt.savefig(os.path.join(a.out, "figs", "roc_curves.png"), dpi=300); plt.close()

    # ablations
    for key, grp in ABL.items():
        r = load(a.runs, grp)
        if r is None:
            continue
        Ma = metrics(r[0], r[1], K)
        for m in ("ACC", "F1", "BACC", "AUC", "MCC"):
            R[f"ABL_{key}_{m}"] = fm(m, Ma[m])
        if key != "FULL" and main_run is not None:
            R[f"ABL_{key}_DACC"] = f"{100 * (Ma['ACC'] - metrics(main_run[0], main_run[1], K)['ACC']):+.2f}"
            R[f"ABL_{key}_DF1"] = f"{100 * (Ma['F1'] - metrics(main_run[0], main_run[1], K)['F1']):+.2f}"
            pv, _, _ = mcnemar(r[1], r[0].argmax(1), main_run[0].argmax(1)); R[f"ABL_{key}_P"] = fp(pv)

    # leakage experiment: same configuration trained/tested on the distributed folders
    lk = load(a.runs, LEAK)
    if lk is not None:
        pl, yl, il = lk; Ml = metrics(pl, yl, K)
        for m in ("ACC", "F1", "BACC", "AUC"):
            R[f"LEAK_{m}"] = fm(m, Ml[m])
        R["LEAK_NTEST"] = str(len(yl))
        if main_run is not None:
            Mm = metrics(main_run[0], main_run[1], K)
            R["LEAK_GAP_ACC"] = f"{100 * (Ml['ACC'] - Mm['ACC']):+.2f}"; R["LEAK_GAP_F1"] = f"{100 * (Ml['F1'] - Mm['F1']):+.2f}"
        if a.audit:
            z = np.load(a.audit, allow_pickle=False); D = z["D"]; af = list(z["files"]); sp = z["sp"]
            pos = {f: i for i, f in enumerate(af)}
            tr_idx = np.where(sp == "train")[0]
            dmin = np.array([D[pos[str(data["files"][j])], tr_idx].min() for j in il])
            ok = pl.argmax(1) == yl
            for nmk, msk in (("DUP", dmin <= 4), ("NODUP", dmin > 6)):
                R[f"LEAK_{nmk}_N"] = str(int(msk.sum())); R[f"LEAK_{nmk}_ACC"] = pct(ok[msk].mean())
            R["LEAK_MID_N"] = str(int(((dmin > 4) & (dmin <= 6)).sum())); R["LEAK_MID_ACC"] = pct(ok[(dmin > 4) & (dmin <= 6)].mean())

    # training curves (main, seed 0)
    hf = os.path.join(a.runs, f"{MAIN}_s0", "history.json")
    if os.path.exists(hf):
        h = json.load(open(hf)); ep = [r["epoch"] + 1 for r in h]
        fig, axs = plt.subplots(1, 3, figsize=(13, 3.6))
        axs[0].plot(ep, [r["train_loss"] for r in h], label="train loss"); axs[0].plot(ep, [r["val_loss"] for r in h], label="validation NLL")
        axs[0].legend(); axs[0].set_title("Loss")
        axs[1].plot(ep, [r["val_acc"] for r in h], label="val accuracy"); axs[1].plot(ep, [r["val_auc"] for r in h], label="val macro-AUC")
        axs[1].legend(); axs[1].set_title("Validation")
        hd_f = os.path.join(a.runs, f"{ABL['LOSS_DWFL']}_s0", "history.json")
        hd = json.load(open(hd_f)) if os.path.exists(hd_f) else h
        if "dwfl_beta" in hd[0]:
            B = np.array([r["dwfl_beta"] for r in hd]); cmap = plt.get_cmap("tab20"); ep_b = [r["epoch"] + 1 for r in hd]
            for k in range(K):
                axs[2].plot(ep_b, B[:, k], color=cmap(k), lw=1, label=classes[k])
            axs[2].set_title(r"DWFL class weights $\beta_k(e)$ (DWFL run)"); axs[2].legend(fontsize=5.5, ncol=2)
            R["BETA_FIRST_MAX"] = classes[int(B[0].argmax())]; R["BETA_LAST_MAX"] = classes[int(B[-1].argmax())]
            R["BETA_LAST_MIN"] = classes[int(B[-1].argmin())]
            R["BETA_RANGE_FIRST"] = f"{B[0].min():.2f}–{B[0].max():.2f}"; R["BETA_RANGE_LAST"] = f"{B[-1].min():.2f}–{B[-1].max():.2f}"
        for ax in axs:
            ax.set_xlabel("Epoch")
        plt.tight_layout(); plt.savefig(os.path.join(a.out, "figs", "training_curves.png"), dpi=300); plt.close()
        best = int(np.argmax([r["val_auc"] for r in h])); R["MAIN_BEST_EPOCH"] = str(best + 1); R["MAIN_EPOCHS_RUN"] = str(len(h))
        R["TIME_EPOCH"] = f"{np.mean([r['time_s'] for r in h]):.0f}"

    for k_, grp in list(BASE.items()) + [("matransnet-S", MAIN)]:
        hf = os.path.join(a.runs, f"{grp}_s0", "history.json")
        if os.path.exists(hf):
            h = json.load(open(hf)); R[f"EPOCHS_{k_.upper()}"] = str(len(h)); R[f"TEPOCH_{k_.upper()}"] = f"{np.mean([r['time_s'] for r in h]):.0f}"

    # ---------------------------------------------------------------- model-based analyses
    if a.robust or a.xai or a.eff:
        import sys
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from model import build_model
        torch.set_num_threads(2)
        imgs = data["imgs"]; te = np.where(data["subset"] == "test")[0]; yte = data["labels"][te]

        def get(name, grp, size="base"):
            run = os.path.join(a.runs, f"{grp}_s0"); cfg = json.load(open(os.path.join(run, "config.json")))
            m = build_model(name, K, 1, 128, pretrained=False, variant=cfg["variant"], size=size).eval()
            m.load_state_dict(torch.load(os.path.join(run, "best.pt"), map_location="cpu")); return m, cfg

        def prep(x01, cfg):
            x = torch.from_numpy(x01.astype(np.float32))[:, None]
            x = F.interpolate(x, size=(128, 128), mode="bilinear", align_corners=False)
            return ((x - cfg["norm_mean"]) / cfg["norm_std"]).contiguous(memory_format=torch.channels_last)

        models = {"matransnet-S": ("matransnet", MAIN, "small")}
        if "BEST_BASELINE_KEY" in R:
            kb = R["BEST_BASELINE_KEY"]; models[kb] = (kb, BASE[kb], "base")

    if a.robust:
        import cv2
        from robustness import rician, bias_field
        conds = {"CLEAN": lambda x, r: x, "RICIAN30": lambda x, r: rician(x, 30, r), "RICIAN20": lambda x, r: rician(x, 20, r),
                 "RICIAN10": lambda x, r: rician(x, 10, r), "BLUR1": lambda x, r: cv2.GaussianBlur(x, (0, 0), 1.0),
                 "BLUR2": lambda x, r: cv2.GaussianBlur(x, (0, 0), 2.0), "BIAS": lambda x, r: bias_field(x, 0.3, r),
                 "GAMMA07": lambda x, r: np.clip(x, 0, None) ** 0.7, "GAMMA15": lambda x, r: np.clip(x, 0, None) ** 1.5,
                 "LOWRES": lambda x, r: cv2.resize(cv2.resize(x, (72, 72), interpolation=cv2.INTER_AREA), (144, 144))}
        for mk, (name, grp, size) in models.items():
            m, cfg = get(name, grp, size)
            for c, fn in conds.items():
                rng = np.random.default_rng(0)
                xs = np.stack([fn(imgs[j].astype(np.float32), rng).astype(np.float32) for j in te])
                with torch.no_grad():
                    P = np.concatenate([F.softmax(m(prep(xs[s:s + 64], cfg)), -1).numpy() for s in range(0, len(te), 64)])
                R[f"ROB_{c}_{mk.upper()}_ACC"] = pct(accuracy_score(yte, P.argmax(1)))
                R[f"ROB_{c}_{mk.upper()}_F1"] = pct(f1_score(yte, P.argmax(1), average="macro"))
            print("robustness", mk, {c: R[f'ROB_{c}_{mk.upper()}_ACC'] for c in conds})

    if a.xai:
        from xai import GradCAM, target_layer
        import cv2
        sel = []
        for k in range(K):                                   # one correctly classified test image per class
            cand = [j for j in te if data["labels"][j] == k]
            sel.append(cand[0] if cand else None)
        energy = {}
        cams = {}
        for mk, (name, grp, size) in models.items():
            m, cfg = get(name, grp, size)
            if name == "matransnet":
                layer, nhwc = m.cam_layer(), False
            elif name == "resnet18":
                layer, nhwc = m.layer4, False
            elif name == "convnext_atto":
                layer, nhwc = m.stages[-1], False
            elif name == "efficientnet_b0":
                layer, nhwc = m.conv_head, False
            elif name == "mobilenetv3":
                layer, nhwc = m.blocks[-1], False
            else:
                continue
            gc = GradCAM(m, layer, nhwc); E = []
            for s in range(0, len(te), 32):
                xb = imgs[te[s:s + 32]].astype(np.float32)
                c, _ = gc(prep(xb, cfg).requires_grad_(True))
                for cam, x01 in zip(c, xb):
                    head = cv2.resize(x01, (128, 128)) > 0.08          # brain/head foreground
                    head = cv2.morphologyEx(head.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8)) > 0
                    E.append(cam[head].sum() / max(cam.sum(), 1e-8))
            energy[mk] = np.array(E)
            R[f"XAI_{mk.upper()}_FG"] = f"{energy[mk].mean():.3f} ± {energy[mk].std(ddof=1):.3f}"
            c, _ = gc(prep(imgs[[j for j in sel if j is not None]].astype(np.float32), cfg).requires_grad_(True))
            cams[mk] = c
        show = [k for k in range(K) if sel[k] is not None]
        cols = 5; rows = int(np.ceil(len(show) / cols)) * len(cams)
        fig, axs = plt.subplots(int(np.ceil(len(show) / cols)) * len(cams), cols, figsize=(2.4 * cols, 2.5 * rows))
        axs = np.atleast_2d(axs)
        for mi, (mk, c) in enumerate(cams.items()):
            for t, k in enumerate(show):
                r_, q = divmod(t, cols); ax = axs[r_ * len(cams) + mi, q]
                ax.imshow(cv2.resize(imgs[sel[k]].astype(np.float32), (128, 128)), cmap="gray")
                ax.imshow(c[t], cmap="jet", alpha=0.42); ax.set_title(f"{classes[k]}\n{PRETTY[mk]}", fontsize=7); ax.axis("off")
        for ax in axs.flat:
            ax.axis("off")
        plt.tight_layout(); plt.savefig(os.path.join(a.out, "figs", "gradcam_examples.png"), dpi=220); plt.close()

    if a.eff:
        from fvcore.nn import FlopCountAnalysis
        from timm.layers import set_fused_attn
        set_fused_attn(False)
        from model import build_model
        specs = {"MATRANSNET-S": ("matransnet", "small", "full")}
        specs.update({b.upper(): (b, "base", "full") for b in BASE})
        specs.update({f"ABL_{k}": ("matransnet", "small", v) for k, v in
                      {"NO_GAAM": "no_gaam", "NO_GATE": "no_gate", "ATTN_FULL": "attn_full", "NO_GSB": "no_gsb", "NO_MSFA": "no_msfa"}.items()})
        for key, (name, size, var) in specs.items():
            m = build_model(name, K, 1, 128, pretrained=False, variant=var, size=size).eval()
            x = torch.randn(1, 1, 128, 128)
            fl = FlopCountAnalysis(m, x); fl.unsupported_ops_warnings(False); fl.uncalled_modules_warnings(False)
            R[f"EFF_{key}_PARAMS"] = f"{sum(p.numel() for p in m.parameters()) / 1e6:.2f}"; R[f"EFF_{key}_FLOPS"] = f"{fl.total() / 1e9:.3f}"
            if not key.startswith("ABL_"):
                m = m.to(memory_format=torch.channels_last); x = x.contiguous(memory_format=torch.channels_last)
                with torch.no_grad():
                    for _ in range(10):
                        m(x)
                    t = time.perf_counter()
                    for _ in range(50):
                        m(x)
                R[f"EFF_{key}_LAT"] = f"{(time.perf_counter() - t) / 50 * 1000:.1f}"
            print(key, R[f"EFF_{key}_PARAMS"], R[f"EFF_{key}_FLOPS"], R.get(f"EFF_{key}_LAT"))

    path = os.path.join(a.out, "results.json")
    old = json.load(open(path)) if os.path.exists(path) else {}
    old.update(R); json.dump(old, open(path, "w"), indent=1, ensure_ascii=False)
    print(f"wrote {len(R)} keys")


if __name__ == "__main__":
    main()
