"""Replace the ⟦KEY⟧ placeholders in the manuscript with values from results/results.json.

Usage: python fill_results.py --docx MA-TransNet_manuscript.docx --results results/results.json \
                              --out MA-TransNet_manuscript_filled.docx
Placeholders without a value are left in place (still highlighted) and listed at the end, so that
nothing is silently invented.
"""
import argparse
import json
import os
import re

from docx import Document
from docx.shared import Inches

TOKEN = re.compile(r"⟦([A-Z0-9_]+)⟧")
FIGS = {"FIG_CONFUSION": "confusion_matrix.png", "FIG_ROC": "roc_curves.png",
        "FIG_CURVES": "training_curves.png", "FIG_GRADCAM": "gradcam_examples.png"}
FIG_W = {"FIG_CONFUSION": 3.6, "FIG_ROC": 6.2, "FIG_CURVES": 6.4, "FIG_GRADCAM": 5.6}


def paragraphs(doc):
    def walk_tables(tables):
        for t in tables:
            for row in t.rows:
                for cell in row.cells:
                    yield from cell.paragraphs
                    yield from walk_tables(cell.tables)
    yield from doc.paragraphs
    yield from walk_tables(doc.tables)
    for s in doc.sections:
        for part in (s.header, s.footer):
            yield from part.paragraphs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docx", required=True); ap.add_argument("--results", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    R = json.load(open(a.results, encoding="utf-8"))
    doc = Document(a.docx)
    found, missing = set(), set()
    figdir = os.path.join(os.path.dirname(os.path.abspath(a.results)), "figs")
    for p in paragraphs(doc):
        if "⟦" not in p.text:
            continue
        mf = re.fullmatch(r"\s*⟦(FIG_[A-Z_]+)⟧\s*", p.text)
        if mf:                                              # figure placeholder paragraph
            found.add(mf.group(1))
            path = os.path.join(figdir, FIGS.get(mf.group(1), ""))
            if mf.group(1) in FIGS and os.path.exists(path):
                for r in p.runs:
                    r.text = ""
                p.runs[0].font.highlight_color = None
                p.runs[0].style = None
                p.runs[0].add_picture(path, width=Inches(FIG_W[mf.group(1)]))
            else:
                missing.add(mf.group(1))
            continue
        for r in p.runs:                                   # normal case: token inside one run
            def sub(m):
                found.add(m.group(1))
                if m.group(1) in R:
                    return str(R[m.group(1)])
                missing.add(m.group(1)); return m.group(0)
            new = TOKEN.sub(sub, r.text)
            if new != r.text:
                r.text = new
                if not TOKEN.search(new):
                    r.font.highlight_color = None
                    if r.style is not None and r.style.name == "Placeholder":
                        r.style = None
        leftover = [m.group(1) for m in TOKEN.finditer(p.text)]
        if any(k in R for k in leftover):
            # token split across runs: collapse runs (formatting of that paragraph is simplified)
            found.update(leftover); missing.difference_update(k for k in leftover if k in R)
            text = TOKEN.sub(lambda m: str(R.get(m.group(1), m.group(0))), p.text)
            for r in p.runs[1:]:
                r.text = ""
            p.runs[0].text = text
            if not TOKEN.search(text):
                p.runs[0].style = None
    doc.save(a.out)
    print(f"placeholders found: {len(found)}; filled: {len(found - missing)}; missing: {len(missing)}")
    if missing:
        print("still unfilled (run the corresponding experiment or edit by hand):")
        for k in sorted(missing):
            print("  ", k)


if __name__ == "__main__":
    main()
